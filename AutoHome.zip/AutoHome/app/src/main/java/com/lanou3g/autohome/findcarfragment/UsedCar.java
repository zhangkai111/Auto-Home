package com.lanou3g.autohome.findcarfragment;

import com.lanou3g.autohome.R;
import com.lanou3g.autohome.base.BaseFragment;

/**
 * Created by dllo on 16/5/10.
 * 二手车
 */
public class UsedCar extends BaseFragment {
    @Override
    public int initLayout() {
        return R.layout.findcar_usedcar;
    }

    @Override
    public void initView() {

    }

    @Override
    public void initData() {

    }
}
