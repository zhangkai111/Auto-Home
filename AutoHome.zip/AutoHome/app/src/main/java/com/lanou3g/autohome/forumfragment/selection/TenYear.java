package com.lanou3g.autohome.forumfragment.selection;

import android.view.View;

import com.lanou3g.autohome.R;
import com.lanou3g.autohome.base.BaseFragment;

/**
 * Created by dllo on 16/5/9.
 */
public class TenYear extends BaseFragment {
    @Override
    public int initLayout() {
        return R.layout.selection_tenyear;
    }

    @Override
    public void initView() {

    }

    @Override
    public void initData() {

    }
}
