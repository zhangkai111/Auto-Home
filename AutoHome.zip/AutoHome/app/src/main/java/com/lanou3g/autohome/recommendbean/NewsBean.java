package com.lanou3g.autohome.recommendbean;

import java.util.List;

/**
 * Created by dllo on 16/5/11.
 */
public class NewsBean {


    /**
     * rowcount : 31819
     * isloadmore : true
     * headlineinfo : {}
     * focusimg : []
     * newslist : [{"dbid":0,"id":888291,"title":"2016亚洲CES：宝马全新概念车亚洲首发","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 14:44:49","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g9/M0E/7C/B0/400x300_0_autohomecar__wKgH31cyztOAP-dzAAFvD9tU9lk940.jpg","replycount":4,"pagecount":1,"jumppage":1,"lasttime":"20160511144449888291","newstype":0,"updatetime":"20160511142111","coverimages":[]},{"dbid":0,"id":888407,"title":"售15.59万 上汽大众新款朗逸运动版上市","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 14:37:30","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M08/5B/98/400x300_0_autohomecar__wKgFVlcy1BaAFqPeAAFBlUpWajY632.jpg","replycount":68,"pagecount":1,"jumppage":1,"lasttime":"20160511143730888407","newstype":0,"updatetime":"20160511144222","coverimages":[]},{"dbid":0,"id":888403,"title":"造型更激进 全新科迈罗Z/28谍照曝光","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 13:00:46","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M02/5B/78/400x300_0_autohomecar__wKjBwFcyu6uARLsCAAGYJLyLdag819.jpg","replycount":62,"pagecount":1,"jumppage":1,"lasttime":"20160511130046888403","newstype":0,"updatetime":"20160511134828","coverimages":[]},{"dbid":0,"id":888401,"title":"基于丰田Hilux打造 PSA将推皮卡车型","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 12:00:39","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g4/M06/78/C7/400x300_0_autohomecar__wKgH2lcypv-AK99zAAGQbTsoDyA716.jpg","replycount":139,"pagecount":1,"jumppage":1,"lasttime":"20160511120039888401","newstype":0,"updatetime":"20160511125540","coverimages":[]},{"dbid":0,"id":888400,"title":"售24.2万 奔驰B级新增入门级B 180车型","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 11:43:23","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M00/78/DC/400x300_0_autohomecar__wKjBzVcypwuAU_g_AAFn2QypSv4872.jpg","replycount":329,"pagecount":1,"jumppage":1,"lasttime":"20160511114323888400","newstype":0,"updatetime":"20160511113544","coverimages":[]},{"dbid":0,"id":888399,"title":"或配V6发动机 全新奥迪RS 5 Coupe谍照","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 11:37:56","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g6/M02/78/E8/400x300_0_autohomecar__wKgH3FcypciAOOZ5AAISbboItF4501.jpg","replycount":137,"pagecount":1,"jumppage":1,"lasttime":"20160511113756888399","newstype":0,"updatetime":"20160511135445","coverimages":[]},{"dbid":0,"id":888388,"title":"共推34款新车 神龙发布5A+中期事业规划","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 11:00:44","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M0C/5A/E9/400x300_0_autohomecar__wKgFVFcymraAJf7AAAGLxkFWjBM740.jpg","replycount":117,"pagecount":1,"jumppage":1,"lasttime":"20160511110044888388","newstype":0,"updatetime":"20160511121058","coverimages":[]},{"dbid":0,"id":888397,"title":"雪佛兰车型2017年在华全系标配智能启停","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 10:59:26","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M02/79/09/400x300_0_autohomecar__wKgH4FcynweAB0C6AAFTyT8VxVw958.jpg","replycount":220,"pagecount":1,"jumppage":1,"lasttime":"20160511105926888397","newstype":0,"updatetime":"20160511105923","coverimages":[]},{"dbid":0,"id":888395,"title":"仅供西班牙 宝马推出M4 CS限量版车型","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 10:50:38","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M04/78/44/400x300_0_autohomecar__wKjBzFcylfKAZyfdAAFxZuoJsHE799.jpg","replycount":105,"pagecount":1,"jumppage":1,"lasttime":"20160511105038888395","newstype":0,"updatetime":"20160511105016","coverimages":[]},{"dbid":0,"id":888327,"title":"售38.90万起 全新福克斯RS国内正式上市","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 10:10:11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g17/M0C/73/D2/400x300_0_autohomecar__wKgH2FcylECAHjWUAAIG1LAihb4036.jpg","replycount":1919,"pagecount":1,"jumppage":1,"lasttime":"20160511101011888327","newstype":0,"updatetime":"20160511101838","coverimages":[]},{"dbid":0,"id":888394,"title":"或今年底发布 曝全新宝马5系GT谍照","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 9:58:45","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g8/M14/7B/DC/400x300_0_autohomecar__wKgH3lcykHmAUTzEAAHbwbIIr_g473.jpg","replycount":187,"pagecount":1,"jumppage":1,"lasttime":"20160511095845888394","newstype":0,"updatetime":"20160511095647","coverimages":[]},{"dbid":0,"id":888391,"title":"向经典致敬 MINI特别版车型官图发布","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 8:05:03","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M04/78/D4/400x300_0_autohomecar__wKgH0lcydiOAJkQHAAE4HZFbMVA051.jpg","replycount":91,"pagecount":1,"jumppage":1,"lasttime":"20160511080503888391","newstype":0,"updatetime":"20160511091421","coverimages":[]},{"dbid":0,"id":888379,"title":"命名睿行S50 长安商用全新MPV最新谍照","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 6:05:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M09/5A/26/400x300_0_autohomecar__wKjBwVcxxkGABrarAAFXdR0OzDk057.jpg","replycount":226,"pagecount":1,"jumppage":1,"lasttime":"20160511060500888379","newstype":0,"updatetime":"20160510193233","coverimages":[]},{"dbid":0,"id":888383,"title":"配三种动力系统 现代IONIQ或8月份入华","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 6:03:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M12/78/4A/400x300_0_autohomecar__wKjBzVcx2PeAELgKAAFtxgcUsqI127.jpg","replycount":144,"pagecount":1,"jumppage":1,"lasttime":"20160511060300888383","newstype":0,"updatetime":"20160510220348","coverimages":[]},{"dbid":0,"id":888387,"title":"大众全新迈特威/凯路威将于5月26日上市","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 6:01:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g6/M0C/77/F6/400x300_0_autohomecar__wKjB0Vcx8G2AcvHmAAF8FPXZxJ4201.jpg","replycount":239,"pagecount":1,"jumppage":1,"lasttime":"20160511060100888387","newstype":0,"updatetime":"20160510223145","coverimages":[]},{"dbid":0,"id":888385,"title":"限量24台 奥迪R8 V10 Plus特别版官图","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 6:01:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M0B/5A/7B/400x300_0_autohomecar__wKgFVFcx6GSAav28AAGDrfLK9O8015.jpg","replycount":301,"pagecount":1,"jumppage":1,"lasttime":"20160511060100888385","newstype":0,"updatetime":"20160510215550","coverimages":[]},{"dbid":0,"id":888375,"title":"数说北京车展：接地气/235款新车看花眼","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 0:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g23/M07/5A/C9/400x300_0_autohomecar__wKgFXFcxprGAGw8kAAHodAlAGnQ503.jpg","replycount":98,"pagecount":4,"jumppage":1,"lasttime":"20160511000000888375","newstype":0,"updatetime":"20160511110340","coverimages":[]},{"dbid":0,"id":888384,"title":"最高降3.18万元 奥迪A5/S5部分车型官降","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 21:22:13","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g14/M15/77/72/400x300_0_autohomecar__wKgH1Vcx4ZyANleDAAFrgATXcg0663.jpg","replycount":514,"pagecount":1,"jumppage":1,"lasttime":"20160510212213888384","newstype":0,"updatetime":"20160510212742","coverimages":[]},{"dbid":0,"id":888378,"title":"2017年亮相 曝福特新一代福克斯假想图","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 20:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g23/M0B/5A/93/400x300_0_autohomecar__wKgFV1cxwAaARUkiAAEMJ5sbVo0506.jpg","replycount":653,"pagecount":1,"jumppage":1,"lasttime":"20160510200500888378","newstype":0,"updatetime":"20160510190436","coverimages":[]},{"dbid":0,"id":888371,"title":"落户如皋？赛麟或在华国产新能源产品","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 20:05:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M01/78/CB/400x300_0_autohomecar__wKgH5FcxnleAWadhAADpXV8U564941.jpg","replycount":237,"pagecount":1,"jumppage":1,"lasttime":"20160510200500888371","newstype":0,"updatetime":"20160510170346","coverimages":[]},{"dbid":0,"id":888373,"title":"限量500辆 DS 3 GIVENCHY EDITION官图","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 17:22:20","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g23/M00/5A/CA/400x300_0_autohomecar__wKgFXFcxpr-AUsxnAAFNS_wF1Z0497.jpg","replycount":182,"pagecount":1,"jumppage":1,"lasttime":"20160510172220888373","newstype":0,"updatetime":"20160510172029","coverimages":[]},{"dbid":0,"id":888374,"title":"或于2017年亮相 奥迪新Q3路试谍照曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 17:15:22","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g11/M06/77/97/400x300_0_autohomecar__wKjBzFcxpUiAe0-fAAF_UXSKygw928.jpg","replycount":165,"pagecount":1,"jumppage":1,"lasttime":"20160510171522888374","newstype":0,"updatetime":"20160510171503","coverimages":[]},{"dbid":0,"id":888347,"title":"或5月上市 奇瑞新款瑞虎3配置信息曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 12:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g8/M08/7A/0F/400x300_0_autohomecar__wKgH3lcweU6AHboJAAF7JilQ_Ns892.jpg","replycount":635,"pagecount":1,"jumppage":1,"lasttime":"20160510120000888347","newstype":0,"updatetime":"20160510164629","coverimages":[]},{"dbid":0,"id":888325,"title":"风阻系数为0.19 奔驰IAA概念车国内首发","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 11:27:18","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M13/5A/19/400x300_0_autohomecar__wKgFVlcxVOqAStVjAAFg6B4-gBo153.jpg","replycount":328,"pagecount":1,"jumppage":1,"lasttime":"20160510112718888325","newstype":0,"updatetime":"20160510113738","coverimages":[]},{"dbid":0,"id":888367,"title":"6月下旬亮相 野马新SUV T80预告图曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 11:19:41","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M04/5A/41/400x300_0_autohomecar__wKgFXFcxUWyAU0kMAAER0hdc568359.jpg","replycount":1160,"pagecount":1,"jumppage":1,"lasttime":"20160510111941888367","newstype":0,"updatetime":"20160510111557","coverimages":[]},{"dbid":0,"id":888366,"title":"或2018年发布 法拉利Dino假想图曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 10:59:51","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g17/M0A/72/0A/400x300_0_autohomecar__wKjBxlcxTSqAVUWkAAEnKtJouUc408.jpg","replycount":292,"pagecount":1,"jumppage":1,"lasttime":"20160510105951888366","newstype":0,"updatetime":"20160510105713","coverimages":[]},{"dbid":0,"id":888364,"title":"2017年3月亮相 捷豹新款F-TYPE谍照曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 10:46:48","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g21/M04/58/A5/400x300_0_autohomecar__wKjBwlcxR4qARfpwAAGraxqvlVI795.jpg","replycount":86,"pagecount":1,"jumppage":1,"lasttime":"20160510104648888364","newstype":0,"updatetime":"20160510104550","coverimages":[]},{"dbid":0,"id":888361,"title":"约300马力 下代牧马人将搭新2.0T发动机","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 10:11:35","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M11/76/8D/400x300_0_autohomecar__wKgH1VcxQA6AeqFvAAGn6utUaTQ403.jpg","replycount":623,"pagecount":1,"jumppage":1,"lasttime":"20160510101135888361","newstype":0,"updatetime":"20160510100919","coverimages":[]},{"dbid":0,"id":888359,"title":"2018年换代 新一代标致508信息曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 10:03:28","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M0C/78/2F/400x300_0_autohomecar__wKgH5FcxOg2AGvENAAFBVAbjBqo249.jpg","replycount":536,"pagecount":1,"jumppage":1,"lasttime":"20160510100328888359","newstype":0,"updatetime":"20160510102119","coverimages":[]},{"dbid":0,"id":888362,"title":"曝兰博基尼Huracan Spyder LP580-2实车","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 9:57:44","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g17/M08/72/7E/400x300_0_autohomecar__wKgH2FcxPymAE3ZqAAFs_Ew4cC4923.jpg","replycount":157,"pagecount":1,"jumppage":1,"lasttime":"20160510095744888362","newstype":0,"updatetime":"20160510095415","coverimages":[]}]
     * topnewsinfo : {}
     */

    private ResultBean result;
    /**
     * result : {"rowcount":31819,"isloadmore":true,"headlineinfo":{},"focusimg":[],"newslist":[{"dbid":0,"id":888291,"title":"2016亚洲CES：宝马全新概念车亚洲首发","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 14:44:49","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g9/M0E/7C/B0/400x300_0_autohomecar__wKgH31cyztOAP-dzAAFvD9tU9lk940.jpg","replycount":4,"pagecount":1,"jumppage":1,"lasttime":"20160511144449888291","newstype":0,"updatetime":"20160511142111","coverimages":[]},{"dbid":0,"id":888407,"title":"售15.59万 上汽大众新款朗逸运动版上市","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 14:37:30","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M08/5B/98/400x300_0_autohomecar__wKgFVlcy1BaAFqPeAAFBlUpWajY632.jpg","replycount":68,"pagecount":1,"jumppage":1,"lasttime":"20160511143730888407","newstype":0,"updatetime":"20160511144222","coverimages":[]},{"dbid":0,"id":888403,"title":"造型更激进 全新科迈罗Z/28谍照曝光","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 13:00:46","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M02/5B/78/400x300_0_autohomecar__wKjBwFcyu6uARLsCAAGYJLyLdag819.jpg","replycount":62,"pagecount":1,"jumppage":1,"lasttime":"20160511130046888403","newstype":0,"updatetime":"20160511134828","coverimages":[]},{"dbid":0,"id":888401,"title":"基于丰田Hilux打造 PSA将推皮卡车型","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 12:00:39","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g4/M06/78/C7/400x300_0_autohomecar__wKgH2lcypv-AK99zAAGQbTsoDyA716.jpg","replycount":139,"pagecount":1,"jumppage":1,"lasttime":"20160511120039888401","newstype":0,"updatetime":"20160511125540","coverimages":[]},{"dbid":0,"id":888400,"title":"售24.2万 奔驰B级新增入门级B 180车型","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 11:43:23","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M00/78/DC/400x300_0_autohomecar__wKjBzVcypwuAU_g_AAFn2QypSv4872.jpg","replycount":329,"pagecount":1,"jumppage":1,"lasttime":"20160511114323888400","newstype":0,"updatetime":"20160511113544","coverimages":[]},{"dbid":0,"id":888399,"title":"或配V6发动机 全新奥迪RS 5 Coupe谍照","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 11:37:56","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g6/M02/78/E8/400x300_0_autohomecar__wKgH3FcypciAOOZ5AAISbboItF4501.jpg","replycount":137,"pagecount":1,"jumppage":1,"lasttime":"20160511113756888399","newstype":0,"updatetime":"20160511135445","coverimages":[]},{"dbid":0,"id":888388,"title":"共推34款新车 神龙发布5A+中期事业规划","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 11:00:44","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M0C/5A/E9/400x300_0_autohomecar__wKgFVFcymraAJf7AAAGLxkFWjBM740.jpg","replycount":117,"pagecount":1,"jumppage":1,"lasttime":"20160511110044888388","newstype":0,"updatetime":"20160511121058","coverimages":[]},{"dbid":0,"id":888397,"title":"雪佛兰车型2017年在华全系标配智能启停","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 10:59:26","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M02/79/09/400x300_0_autohomecar__wKgH4FcynweAB0C6AAFTyT8VxVw958.jpg","replycount":220,"pagecount":1,"jumppage":1,"lasttime":"20160511105926888397","newstype":0,"updatetime":"20160511105923","coverimages":[]},{"dbid":0,"id":888395,"title":"仅供西班牙 宝马推出M4 CS限量版车型","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 10:50:38","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M04/78/44/400x300_0_autohomecar__wKjBzFcylfKAZyfdAAFxZuoJsHE799.jpg","replycount":105,"pagecount":1,"jumppage":1,"lasttime":"20160511105038888395","newstype":0,"updatetime":"20160511105016","coverimages":[]},{"dbid":0,"id":888327,"title":"售38.90万起 全新福克斯RS国内正式上市","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 10:10:11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g17/M0C/73/D2/400x300_0_autohomecar__wKgH2FcylECAHjWUAAIG1LAihb4036.jpg","replycount":1919,"pagecount":1,"jumppage":1,"lasttime":"20160511101011888327","newstype":0,"updatetime":"20160511101838","coverimages":[]},{"dbid":0,"id":888394,"title":"或今年底发布 曝全新宝马5系GT谍照","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 9:58:45","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g8/M14/7B/DC/400x300_0_autohomecar__wKgH3lcykHmAUTzEAAHbwbIIr_g473.jpg","replycount":187,"pagecount":1,"jumppage":1,"lasttime":"20160511095845888394","newstype":0,"updatetime":"20160511095647","coverimages":[]},{"dbid":0,"id":888391,"title":"向经典致敬 MINI特别版车型官图发布","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 8:05:03","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M04/78/D4/400x300_0_autohomecar__wKgH0lcydiOAJkQHAAE4HZFbMVA051.jpg","replycount":91,"pagecount":1,"jumppage":1,"lasttime":"20160511080503888391","newstype":0,"updatetime":"20160511091421","coverimages":[]},{"dbid":0,"id":888379,"title":"命名睿行S50 长安商用全新MPV最新谍照","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 6:05:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M09/5A/26/400x300_0_autohomecar__wKjBwVcxxkGABrarAAFXdR0OzDk057.jpg","replycount":226,"pagecount":1,"jumppage":1,"lasttime":"20160511060500888379","newstype":0,"updatetime":"20160510193233","coverimages":[]},{"dbid":0,"id":888383,"title":"配三种动力系统 现代IONIQ或8月份入华","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 6:03:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M12/78/4A/400x300_0_autohomecar__wKjBzVcx2PeAELgKAAFtxgcUsqI127.jpg","replycount":144,"pagecount":1,"jumppage":1,"lasttime":"20160511060300888383","newstype":0,"updatetime":"20160510220348","coverimages":[]},{"dbid":0,"id":888387,"title":"大众全新迈特威/凯路威将于5月26日上市","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 6:01:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g6/M0C/77/F6/400x300_0_autohomecar__wKjB0Vcx8G2AcvHmAAF8FPXZxJ4201.jpg","replycount":239,"pagecount":1,"jumppage":1,"lasttime":"20160511060100888387","newstype":0,"updatetime":"20160510223145","coverimages":[]},{"dbid":0,"id":888385,"title":"限量24台 奥迪R8 V10 Plus特别版官图","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 6:01:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M0B/5A/7B/400x300_0_autohomecar__wKgFVFcx6GSAav28AAGDrfLK9O8015.jpg","replycount":301,"pagecount":1,"jumppage":1,"lasttime":"20160511060100888385","newstype":0,"updatetime":"20160510215550","coverimages":[]},{"dbid":0,"id":888375,"title":"数说北京车展：接地气/235款新车看花眼","mediatype":0,"type":"新闻中心","time":"2016-05-11","intacttime":"2016/5/11 0:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g23/M07/5A/C9/400x300_0_autohomecar__wKgFXFcxprGAGw8kAAHodAlAGnQ503.jpg","replycount":98,"pagecount":4,"jumppage":1,"lasttime":"20160511000000888375","newstype":0,"updatetime":"20160511110340","coverimages":[]},{"dbid":0,"id":888384,"title":"最高降3.18万元 奥迪A5/S5部分车型官降","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 21:22:13","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g14/M15/77/72/400x300_0_autohomecar__wKgH1Vcx4ZyANleDAAFrgATXcg0663.jpg","replycount":514,"pagecount":1,"jumppage":1,"lasttime":"20160510212213888384","newstype":0,"updatetime":"20160510212742","coverimages":[]},{"dbid":0,"id":888378,"title":"2017年亮相 曝福特新一代福克斯假想图","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 20:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g23/M0B/5A/93/400x300_0_autohomecar__wKgFV1cxwAaARUkiAAEMJ5sbVo0506.jpg","replycount":653,"pagecount":1,"jumppage":1,"lasttime":"20160510200500888378","newstype":0,"updatetime":"20160510190436","coverimages":[]},{"dbid":0,"id":888371,"title":"落户如皋？赛麟或在华国产新能源产品","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 20:05:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M01/78/CB/400x300_0_autohomecar__wKgH5FcxnleAWadhAADpXV8U564941.jpg","replycount":237,"pagecount":1,"jumppage":1,"lasttime":"20160510200500888371","newstype":0,"updatetime":"20160510170346","coverimages":[]},{"dbid":0,"id":888373,"title":"限量500辆 DS 3 GIVENCHY EDITION官图","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 17:22:20","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g23/M00/5A/CA/400x300_0_autohomecar__wKgFXFcxpr-AUsxnAAFNS_wF1Z0497.jpg","replycount":182,"pagecount":1,"jumppage":1,"lasttime":"20160510172220888373","newstype":0,"updatetime":"20160510172029","coverimages":[]},{"dbid":0,"id":888374,"title":"或于2017年亮相 奥迪新Q3路试谍照曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 17:15:22","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g11/M06/77/97/400x300_0_autohomecar__wKjBzFcxpUiAe0-fAAF_UXSKygw928.jpg","replycount":165,"pagecount":1,"jumppage":1,"lasttime":"20160510171522888374","newstype":0,"updatetime":"20160510171503","coverimages":[]},{"dbid":0,"id":888347,"title":"或5月上市 奇瑞新款瑞虎3配置信息曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 12:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g8/M08/7A/0F/400x300_0_autohomecar__wKgH3lcweU6AHboJAAF7JilQ_Ns892.jpg","replycount":635,"pagecount":1,"jumppage":1,"lasttime":"20160510120000888347","newstype":0,"updatetime":"20160510164629","coverimages":[]},{"dbid":0,"id":888325,"title":"风阻系数为0.19 奔驰IAA概念车国内首发","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 11:27:18","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M13/5A/19/400x300_0_autohomecar__wKgFVlcxVOqAStVjAAFg6B4-gBo153.jpg","replycount":328,"pagecount":1,"jumppage":1,"lasttime":"20160510112718888325","newstype":0,"updatetime":"20160510113738","coverimages":[]},{"dbid":0,"id":888367,"title":"6月下旬亮相 野马新SUV T80预告图曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 11:19:41","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M04/5A/41/400x300_0_autohomecar__wKgFXFcxUWyAU0kMAAER0hdc568359.jpg","replycount":1160,"pagecount":1,"jumppage":1,"lasttime":"20160510111941888367","newstype":0,"updatetime":"20160510111557","coverimages":[]},{"dbid":0,"id":888366,"title":"或2018年发布 法拉利Dino假想图曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 10:59:51","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g17/M0A/72/0A/400x300_0_autohomecar__wKjBxlcxTSqAVUWkAAEnKtJouUc408.jpg","replycount":292,"pagecount":1,"jumppage":1,"lasttime":"20160510105951888366","newstype":0,"updatetime":"20160510105713","coverimages":[]},{"dbid":0,"id":888364,"title":"2017年3月亮相 捷豹新款F-TYPE谍照曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 10:46:48","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g21/M04/58/A5/400x300_0_autohomecar__wKjBwlcxR4qARfpwAAGraxqvlVI795.jpg","replycount":86,"pagecount":1,"jumppage":1,"lasttime":"20160510104648888364","newstype":0,"updatetime":"20160510104550","coverimages":[]},{"dbid":0,"id":888361,"title":"约300马力 下代牧马人将搭新2.0T发动机","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 10:11:35","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M11/76/8D/400x300_0_autohomecar__wKgH1VcxQA6AeqFvAAGn6utUaTQ403.jpg","replycount":623,"pagecount":1,"jumppage":1,"lasttime":"20160510101135888361","newstype":0,"updatetime":"20160510100919","coverimages":[]},{"dbid":0,"id":888359,"title":"2018年换代 新一代标致508信息曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 10:03:28","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M0C/78/2F/400x300_0_autohomecar__wKgH5FcxOg2AGvENAAFBVAbjBqo249.jpg","replycount":536,"pagecount":1,"jumppage":1,"lasttime":"20160510100328888359","newstype":0,"updatetime":"20160510102119","coverimages":[]},{"dbid":0,"id":888362,"title":"曝兰博基尼Huracan Spyder LP580-2实车","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 9:57:44","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g17/M08/72/7E/400x300_0_autohomecar__wKgH2FcxPymAE3ZqAAFs_Ew4cC4923.jpg","replycount":157,"pagecount":1,"jumppage":1,"lasttime":"20160510095744888362","newstype":0,"updatetime":"20160510095415","coverimages":[]}],"topnewsinfo":{}}
     * returncode : 0
     * message :
     */

    private int returncode;
    private String message;

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class ResultBean {
        private int rowcount;
        private boolean isloadmore;
        private List<?> focusimg;
        /**
         * dbid : 0
         * id : 888291
         * title : 2016亚洲CES：宝马全新概念车亚洲首发
         * mediatype : 0
         * type : 新闻中心
         * time : 2016-05-11
         * intacttime : 2016/5/11 14:44:49
         * indexdetail :
         * smallpic : http://www2.autoimg.cn/newsdfs/g9/M0E/7C/B0/400x300_0_autohomecar__wKgH31cyztOAP-dzAAFvD9tU9lk940.jpg
         * replycount : 4
         * pagecount : 1
         * jumppage : 1
         * lasttime : 20160511144449888291
         * newstype : 0
         * updatetime : 20160511142111
         * coverimages : []
         */

        private List<NewslistBean> newslist;

        public int getRowcount() {
            return rowcount;
        }

        public void setRowcount(int rowcount) {
            this.rowcount = rowcount;
        }

        public boolean isIsloadmore() {
            return isloadmore;
        }

        public void setIsloadmore(boolean isloadmore) {
            this.isloadmore = isloadmore;
        }

        public List<?> getFocusimg() {
            return focusimg;
        }

        public void setFocusimg(List<?> focusimg) {
            this.focusimg = focusimg;
        }

        public List<NewslistBean> getNewslist() {
            return newslist;
        }

        public void setNewslist(List<NewslistBean> newslist) {
            this.newslist = newslist;
        }

        public static class NewslistBean {
            private int dbid;
            private int id;
            private String title;
            private int mediatype;
            private String type;
            private String time;
            private String intacttime;
            private String indexdetail;
            private String smallpic;
            private int replycount;
            private int pagecount;
            private int jumppage;
            private String lasttime;
            private int newstype;
            private String updatetime;
            private List<?> coverimages;

            public int getDbid() {
                return dbid;
            }

            public void setDbid(int dbid) {
                this.dbid = dbid;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public int getMediatype() {
                return mediatype;
            }

            public void setMediatype(int mediatype) {
                this.mediatype = mediatype;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getIntacttime() {
                return intacttime;
            }

            public void setIntacttime(String intacttime) {
                this.intacttime = intacttime;
            }

            public String getIndexdetail() {
                return indexdetail;
            }

            public void setIndexdetail(String indexdetail) {
                this.indexdetail = indexdetail;
            }

            public String getSmallpic() {
                return smallpic;
            }

            public void setSmallpic(String smallpic) {
                this.smallpic = smallpic;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }

            public int getPagecount() {
                return pagecount;
            }

            public void setPagecount(int pagecount) {
                this.pagecount = pagecount;
            }

            public int getJumppage() {
                return jumppage;
            }

            public void setJumppage(int jumppage) {
                this.jumppage = jumppage;
            }

            public String getLasttime() {
                return lasttime;
            }

            public void setLasttime(String lasttime) {
                this.lasttime = lasttime;
            }

            public int getNewstype() {
                return newstype;
            }

            public void setNewstype(int newstype) {
                this.newstype = newstype;
            }

            public String getUpdatetime() {
                return updatetime;
            }

            public void setUpdatetime(String updatetime) {
                this.updatetime = updatetime;
            }

            public List<?> getCoverimages() {
                return coverimages;
            }

            public void setCoverimages(List<?> coverimages) {
                this.coverimages = coverimages;
            }
        }
    }
}
