package com.lanou3g.autohome.recommendfragment;

import com.lanou3g.autohome.R;
import com.lanou3g.autohome.base.BaseFragment;

/**
 * Created by dllo on 16/5/9.
 * 说客
 */
public class Lobbyist extends BaseFragment{
    @Override
    public int initLayout() {
        return R.layout.recommend_lobbyist;
    }

    @Override
    public void initView() {

    }

    @Override
    public void initData() {

    }
}
