package com.lanou3g.autohome.forumfragment;

import com.lanou3g.autohome.R;
import com.lanou3g.autohome.base.BaseFragment;

/**
 * Created by dllo on 16/5/9.
 * 常用论坛
 */
public class Common extends BaseFragment {
    @Override
    public int initLayout() {
        return R.layout.forum_common;
    }

    @Override
    public void initView() {

    }

    @Override
    public void initData() {

    }
}
