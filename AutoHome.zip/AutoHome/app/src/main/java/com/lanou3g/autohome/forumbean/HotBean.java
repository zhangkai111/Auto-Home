package com.lanou3g.autohome.forumbean;

import java.util.List;

/**
 * Created by dllo on 16/5/19.
 */
public class HotBean {

    /**
     * returncode : 0
     * message :
     * result : {"pagecount":4,"rowcount":27989,"pageindex":1,"list":[{"topicid":52580087,"title":"\u201c威风凛凛\u201d霸气的小三婚车迎娶今天最美的你\u201c新娘\u201d","lastreplydate":"2016-05-19 19:50:04","postusername":"1m也是钱","replycounts":57,"ispictopic":1,"bbsid":3080,"bbsname":"瑞风S3论坛","postdate":"2016-05-18 20:08:35"},{"topicid":52580236,"title":"5.21发布价格，6.21正式发售，内附详情","lastreplydate":"2016-05-19 19:30:05","postusername":"菠萝大叔","replycounts":140,"ispictopic":1,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-18 20:14:20"},{"topicid":52588244,"title":"如果真的是这个价格   我就跟rx5无缘了","lastreplydate":"2016-05-19 19:47:22","postusername":"直行巨蟹","replycounts":120,"ispictopic":1,"bbsid":4080,"bbsname":"荣威RX5论坛","postdate":"2016-05-19 02:15:06"},{"topicid":52600819,"title":"以看博越为名，拍大波妹子，持续更新！啪啪啪不如拍拍拍！","lastreplydate":"2016-05-19 19:48:43","postusername":"唯我独尊冷云","replycounts":165,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 14:22:11"},{"topicid":52594603,"title":"对比了这么多合资车，还是决定死守博越！","lastreplydate":"2016-05-19 19:39:34","postusername":"_浅墨淡痕_","replycounts":27,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 10:57:22"},{"topicid":52591791,"title":"女友出差了，女友闺蜜晚上打电话给我说她家钥匙丢了要来我家待会","lastreplydate":"2016-05-19 19:51:06","postusername":"栎阳鹤翔","replycounts":87,"ispictopic":1,"bbsid":135,"bbsname":"思域论坛","postdate":"2016-05-19 09:36:16"},{"topicid":52589917,"title":"全是刚出炉的","lastreplydate":"2016-05-19 19:46:56","postusername":"h122370755","replycounts":15,"ispictopic":1,"bbsid":3957,"bbsname":"西玛论坛","postdate":"2016-05-19 08:11:19"},{"topicid":52587101,"title":"新疆撼家军32辆再集结，4S全力保障，踏进库木塔格沙漠（多图）","lastreplydate":"2016-05-19 18:54:26","postusername":"scorpion515","replycounts":198,"ispictopic":1,"bbsid":3518,"bbsname":"撼路者论坛","postdate":"2016-05-19 00:18:05"},{"topicid":52590072,"title":"迎来了人生第一辆属于自己的新车、525豪华。","lastreplydate":"2016-05-19 19:28:41","postusername":"牛凯文","replycounts":101,"ispictopic":1,"bbsid":65,"bbsname":"宝马5系论坛","postdate":"2016-05-19 08:20:48"},{"topicid":52596488,"title":"千呼万唤始出来！媳妇当车模为520福利\u2014\u2014致凯迪拉克CT6第三专辑","lastreplydate":"2016-05-19 19:24:10","postusername":"北方舰队","replycounts":48,"ispictopic":1,"bbsid":3802,"bbsname":"凯迪拉克CT6论坛","postdate":"2016-05-19 11:50:51"},{"topicid":52582379,"title":"不刻意的诱惑，不克制的爱，娇妻与爱车才是不二情书","lastreplydate":"2016-05-19 19:50:39","postusername":"浪迹天涯时光如琥珀","replycounts":309,"ispictopic":1,"bbsid":3126,"bbsname":"YARiS L 致炫论坛","postdate":"2016-05-18 21:31:01"},{"topicid":52599441,"title":"国产SUV最新高度来了，看样子是完全超越博越啊。。。。","lastreplydate":"2016-05-19 19:49:23","postusername":"神头1号","replycounts":205,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 13:34:47"},{"topicid":52591748,"title":"山西晋城首提智尊博越！94年小伙谈谈感受！已认证，求加精！","lastreplydate":"2016-05-19 19:42:37","postusername":"皇家骑士888","replycounts":195,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 09:34:53"},{"topicid":52590957,"title":"帝豪GS的弱智设计！！！","lastreplydate":"2016-05-19 19:45:00","postusername":"武汉小杨005","replycounts":63,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-19 09:05:07"},{"topicid":52587116,"title":"感觉上奇骏上错了","lastreplydate":"2016-05-19 19:40:39","postusername":"岁月无声88","replycounts":131,"ispictopic":1,"bbsid":656,"bbsname":"奇骏论坛","postdate":"2016-05-19 00:19:07"},{"topicid":52580212,"title":"请删除此楼","lastreplydate":"2016-05-19 17:36:26","postusername":"你姐夫的妹夫","replycounts":81,"ispictopic":0,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-18 20:13:17"},{"topicid":52581722,"title":"男人为啥不买汉兰达～买了宝沃～（告诉你最真实原因）～～","lastreplydate":"2016-05-19 19:42:09","postusername":"江粤998","replycounts":35,"ispictopic":1,"bbsid":3913,"bbsname":"宝沃BX7论坛","postdate":"2016-05-18 21:07:33"},{"topicid":52584431,"title":"中奖了，200公里，cvt","lastreplydate":"2016-05-19 14:02:37","postusername":"我骗你的","replycounts":882,"ispictopic":1,"bbsid":3405,"bbsname":"艾瑞泽5论坛","postdate":"2016-05-18 22:31:15"},{"topicid":52586149,"title":"老牛提车记（2）-图片集","lastreplydate":"2016-05-19 19:31:09","postusername":"liuzhiling2016","replycounts":268,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-18 23:33:11"},{"topicid":52579717,"title":"吉利领导能出来介绍一下吗？城市预碰撞系统没起作用！","lastreplydate":"2016-05-19 19:17:48","postusername":"囹圄囚徒","replycounts":129,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-18 19:55:17"},{"topicid":52593442,"title":"酒驾与醉驾, 害人害己","lastreplydate":"2016-05-19 19:49:39","postusername":"别动我的凯迪","replycounts":53,"ispictopic":1,"bbsid":2334,"bbsname":"众泰T600论坛","postdate":"2016-05-19 10:26:54"},{"topicid":52590248,"title":"艾瑞泽5艾瑞泽5艾瑞泽5","lastreplydate":"2016-05-19 19:41:12","postusername":"311ybb","replycounts":193,"ispictopic":0,"bbsid":3405,"bbsname":"艾瑞泽5论坛","postdate":"2016-05-19 08:31:17"},{"topicid":52595546,"title":"艾瑞泽5艾瑞泽5艾瑞泽5","lastreplydate":"2016-05-19 19:44:00","postusername":"速度与激情的追逐","replycounts":226,"ispictopic":1,"bbsid":3405,"bbsname":"艾瑞泽5论坛","postdate":"2016-05-19 11:23:01"},{"topicid":52597703,"title":"E180L\\E200L\\E300L谍照出来，哪款值得买？","lastreplydate":"2016-05-19 19:37:46","postusername":"唱情歌de人","replycounts":32,"ispictopic":1,"bbsid":197,"bbsname":"奔驰E级论坛","postdate":"2016-05-19 12:33:07"},{"topicid":52603212,"title":"博越首撞心疼死我了。","lastreplydate":"2016-05-19 19:32:33","postusername":"爱博越2016","replycounts":83,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 15:31:01"},{"topicid":52591704,"title":"许诺已久的媳妇当车模！欢迎各位来顶顶贴！哈哈","lastreplydate":"2016-05-19 19:49:12","postusername":"六蚊","replycounts":248,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 09:33:26"},{"topicid":52593383,"title":"东博西蒙南帕北K\u2014\u2014妹子和下雨天更配","lastreplydate":"2016-05-19 19:22:51","postusername":"电动车商行","replycounts":29,"ispictopic":1,"bbsid":3589,"bbsname":"博瑞论坛","postdate":"2016-05-19 10:24:59"},{"topicid":52582691,"title":"一汽最老残的设计","lastreplydate":"2016-05-19 19:50:32","postusername":"别动我的凯迪","replycounts":79,"ispictopic":1,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-18 21:41:38"},{"topicid":52583431,"title":"花臂姑娘","lastreplydate":"2016-05-19 19:41:25","postusername":"一些女孩的人们","replycounts":74,"ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-05-18 22:03:09"},{"topicid":52595156,"title":"[原创说车9.5]-再说一些CX-4的信息","lastreplydate":"2016-05-19 19:23:28","postusername":"翼展风凌","replycounts":78,"ispictopic":1,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-19 11:12:03"},{"topicid":52589480,"title":"【认证帖】江淮老车主！喜提瑞风S3 ,申请精华！","lastreplydate":"2016-05-19 19:39:09","postusername":"hhh075800","replycounts":31,"ispictopic":1,"bbsid":3080,"bbsname":"瑞风S3论坛","postdate":"2016-05-19 07:39:07"},{"topicid":52584686,"title":"【美女买车求荐】好像新思域挺适合我的，大家觉得呢？有爆照哦！","lastreplydate":"2016-05-19 19:03:57","postusername":"这是昵称1","replycounts":79,"ispictopic":1,"bbsid":9901135,"bbsname":"新思域论坛","postdate":"2016-05-18 22:39:52"},{"topicid":52595488,"title":"送上航拍森雅R7视频图片·最后附上视频连接·不喜勿喷·","lastreplydate":"2016-05-19 19:09:27","postusername":"江汉爱车人","replycounts":30,"ispictopic":1,"bbsid":3824,"bbsname":"森雅R7论坛","postdate":"2016-05-19 11:21:32"},{"topicid":52584035,"title":"【李叫兽】之GS百米加速，野外半坡，高速80100120的噪音加速视频","lastreplydate":"2016-05-19 19:43:22","postusername":"点坑","replycounts":553,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-18 22:19:59"},{"topicid":52582074,"title":"美不美，看大腿，未成年人谨慎进去","lastreplydate":"2016-05-19 19:43:44","postusername":"坏男孩9","replycounts":72,"ispictopic":1,"bbsid":9901135,"bbsname":"新思域论坛","postdate":"2016-05-18 21:20:18"},{"topicid":52585954,"title":"5.20博越我爱你，博越车机功能简单阐述及问题解答","lastreplydate":"2016-05-19 19:39:33","postusername":"wang9177","replycounts":105,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-18 23:25:09"},{"topicid":52593131,"title":"H7出车祸了","lastreplydate":"2016-05-19 19:49:50","postusername":"裴建成1688","replycounts":116,"ispictopic":1,"bbsid":3074,"bbsname":"哈弗H7论坛","postdate":"2016-05-19 10:18:03"},{"topicid":52581139,"title":"16款一汽版VX提车各功能详细介绍以及认证！","lastreplydate":"2016-05-19 18:12:21","postusername":"dl_sky","replycounts":82,"ispictopic":1,"bbsid":45,"bbsname":"兰德酷路泽论坛","postdate":"2016-05-18 20:45:48"},{"topicid":52580333,"title":"博越车身拉花，腰线贴纸，喜欢拿去，不喜勿喷！","lastreplydate":"2016-05-19 18:06:23","postusername":"zybilqyn","replycounts":72,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-18 20:18:21"},{"topicid":52580960,"title":"城市喧嚷中片刻的宁静  晴天白云一抹蓝 超低清大片来袭~","lastreplydate":"2016-05-19 18:56:12","postusername":"ly158158","replycounts":79,"ispictopic":1,"bbsid":3899,"bbsname":"众泰SR7论坛","postdate":"2016-05-18 20:39:54"},{"topicid":52582233,"title":"提楼兰两个月作业","lastreplydate":"2016-05-19 18:30:57","postusername":"haroun_chen","replycounts":16,"ispictopic":1,"bbsid":2381,"bbsname":"楼兰论坛","postdate":"2016-05-18 21:26:15"},{"topicid":52589515,"title":"自己把宝贝倒车时压了，急需救命","lastreplydate":"2016-05-19 19:51:07","postusername":"虚之无月","replycounts":265,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-19 07:41:57"},{"topicid":52581462,"title":"今天看了CX-4 2.0次顶配","lastreplydate":"2016-05-19 19:40:01","postusername":"半时晴空半时雨","replycounts":134,"ispictopic":1,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-18 20:57:45"},{"topicid":52589362,"title":"全面解析交强险","lastreplydate":"2016-05-19 19:30:18","postusername":"赵1590823","replycounts":50,"ispictopic":1,"bbsid":2334,"bbsname":"众泰T600论坛","postdate":"2016-05-19 07:26:36"},{"topicid":52579709,"title":"终于订车啦！西玛，等你回家！","lastreplydate":"2016-05-19 17:22:30","postusername":"阿勉001255","replycounts":19,"ispictopic":0,"bbsid":3957,"bbsname":"西玛论坛","postdate":"2016-05-18 19:55:01"},{"topicid":52585917,"title":"宁波首台手豪十思\u2014\u2014迟来的作业","lastreplydate":"2016-05-19 19:37:21","postusername":"寇小威","replycounts":257,"ispictopic":1,"bbsid":9901135,"bbsname":"新思域论坛","postdate":"2016-05-18 23:23:47"},{"topicid":52580442,"title":"一个月就三万了！！纠结了。。降这么快的车能买吗。。。。。","lastreplydate":"2016-05-19 19:44:36","postusername":"潜炳光瑞邦水泵","replycounts":75,"ispictopic":0,"bbsid":3989,"bbsname":"凯迪拉克XT5论坛","postdate":"2016-05-18 20:22:17"},{"topicid":52580186,"title":"520提前过，今生今生，只愿意给你专属的守候","lastreplydate":"2016-05-19 18:29:09","postusername":"木马么么哒","replycounts":59,"ispictopic":1,"bbsid":18,"bbsname":"奥迪A6L论坛","postdate":"2016-05-18 20:12:21"},{"topicid":52580525,"title":"迎娶亲爱的小五--苏州博越两驱至尊提车作业","lastreplydate":"2016-05-19 19:45:29","postusername":"szlgy","replycounts":82,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-18 20:25:03"}]}
     */

    private int returncode;
    private String message;
    /**
     * pagecount : 4
     * rowcount : 27989
     * pageindex : 1
     * list : [{"topicid":52580087,"title":"\u201c威风凛凛\u201d霸气的小三婚车迎娶今天最美的你\u201c新娘\u201d","lastreplydate":"2016-05-19 19:50:04","postusername":"1m也是钱","replycounts":57,"ispictopic":1,"bbsid":3080,"bbsname":"瑞风S3论坛","postdate":"2016-05-18 20:08:35"},{"topicid":52580236,"title":"5.21发布价格，6.21正式发售，内附详情","lastreplydate":"2016-05-19 19:30:05","postusername":"菠萝大叔","replycounts":140,"ispictopic":1,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-18 20:14:20"},{"topicid":52588244,"title":"如果真的是这个价格   我就跟rx5无缘了","lastreplydate":"2016-05-19 19:47:22","postusername":"直行巨蟹","replycounts":120,"ispictopic":1,"bbsid":4080,"bbsname":"荣威RX5论坛","postdate":"2016-05-19 02:15:06"},{"topicid":52600819,"title":"以看博越为名，拍大波妹子，持续更新！啪啪啪不如拍拍拍！","lastreplydate":"2016-05-19 19:48:43","postusername":"唯我独尊冷云","replycounts":165,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 14:22:11"},{"topicid":52594603,"title":"对比了这么多合资车，还是决定死守博越！","lastreplydate":"2016-05-19 19:39:34","postusername":"_浅墨淡痕_","replycounts":27,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 10:57:22"},{"topicid":52591791,"title":"女友出差了，女友闺蜜晚上打电话给我说她家钥匙丢了要来我家待会","lastreplydate":"2016-05-19 19:51:06","postusername":"栎阳鹤翔","replycounts":87,"ispictopic":1,"bbsid":135,"bbsname":"思域论坛","postdate":"2016-05-19 09:36:16"},{"topicid":52589917,"title":"全是刚出炉的","lastreplydate":"2016-05-19 19:46:56","postusername":"h122370755","replycounts":15,"ispictopic":1,"bbsid":3957,"bbsname":"西玛论坛","postdate":"2016-05-19 08:11:19"},{"topicid":52587101,"title":"新疆撼家军32辆再集结，4S全力保障，踏进库木塔格沙漠（多图）","lastreplydate":"2016-05-19 18:54:26","postusername":"scorpion515","replycounts":198,"ispictopic":1,"bbsid":3518,"bbsname":"撼路者论坛","postdate":"2016-05-19 00:18:05"},{"topicid":52590072,"title":"迎来了人生第一辆属于自己的新车、525豪华。","lastreplydate":"2016-05-19 19:28:41","postusername":"牛凯文","replycounts":101,"ispictopic":1,"bbsid":65,"bbsname":"宝马5系论坛","postdate":"2016-05-19 08:20:48"},{"topicid":52596488,"title":"千呼万唤始出来！媳妇当车模为520福利\u2014\u2014致凯迪拉克CT6第三专辑","lastreplydate":"2016-05-19 19:24:10","postusername":"北方舰队","replycounts":48,"ispictopic":1,"bbsid":3802,"bbsname":"凯迪拉克CT6论坛","postdate":"2016-05-19 11:50:51"},{"topicid":52582379,"title":"不刻意的诱惑，不克制的爱，娇妻与爱车才是不二情书","lastreplydate":"2016-05-19 19:50:39","postusername":"浪迹天涯时光如琥珀","replycounts":309,"ispictopic":1,"bbsid":3126,"bbsname":"YARiS L 致炫论坛","postdate":"2016-05-18 21:31:01"},{"topicid":52599441,"title":"国产SUV最新高度来了，看样子是完全超越博越啊。。。。","lastreplydate":"2016-05-19 19:49:23","postusername":"神头1号","replycounts":205,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 13:34:47"},{"topicid":52591748,"title":"山西晋城首提智尊博越！94年小伙谈谈感受！已认证，求加精！","lastreplydate":"2016-05-19 19:42:37","postusername":"皇家骑士888","replycounts":195,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 09:34:53"},{"topicid":52590957,"title":"帝豪GS的弱智设计！！！","lastreplydate":"2016-05-19 19:45:00","postusername":"武汉小杨005","replycounts":63,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-19 09:05:07"},{"topicid":52587116,"title":"感觉上奇骏上错了","lastreplydate":"2016-05-19 19:40:39","postusername":"岁月无声88","replycounts":131,"ispictopic":1,"bbsid":656,"bbsname":"奇骏论坛","postdate":"2016-05-19 00:19:07"},{"topicid":52580212,"title":"请删除此楼","lastreplydate":"2016-05-19 17:36:26","postusername":"你姐夫的妹夫","replycounts":81,"ispictopic":0,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-18 20:13:17"},{"topicid":52581722,"title":"男人为啥不买汉兰达～买了宝沃～（告诉你最真实原因）～～","lastreplydate":"2016-05-19 19:42:09","postusername":"江粤998","replycounts":35,"ispictopic":1,"bbsid":3913,"bbsname":"宝沃BX7论坛","postdate":"2016-05-18 21:07:33"},{"topicid":52584431,"title":"中奖了，200公里，cvt","lastreplydate":"2016-05-19 14:02:37","postusername":"我骗你的","replycounts":882,"ispictopic":1,"bbsid":3405,"bbsname":"艾瑞泽5论坛","postdate":"2016-05-18 22:31:15"},{"topicid":52586149,"title":"老牛提车记（2）-图片集","lastreplydate":"2016-05-19 19:31:09","postusername":"liuzhiling2016","replycounts":268,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-18 23:33:11"},{"topicid":52579717,"title":"吉利领导能出来介绍一下吗？城市预碰撞系统没起作用！","lastreplydate":"2016-05-19 19:17:48","postusername":"囹圄囚徒","replycounts":129,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-18 19:55:17"},{"topicid":52593442,"title":"酒驾与醉驾, 害人害己","lastreplydate":"2016-05-19 19:49:39","postusername":"别动我的凯迪","replycounts":53,"ispictopic":1,"bbsid":2334,"bbsname":"众泰T600论坛","postdate":"2016-05-19 10:26:54"},{"topicid":52590248,"title":"艾瑞泽5艾瑞泽5艾瑞泽5","lastreplydate":"2016-05-19 19:41:12","postusername":"311ybb","replycounts":193,"ispictopic":0,"bbsid":3405,"bbsname":"艾瑞泽5论坛","postdate":"2016-05-19 08:31:17"},{"topicid":52595546,"title":"艾瑞泽5艾瑞泽5艾瑞泽5","lastreplydate":"2016-05-19 19:44:00","postusername":"速度与激情的追逐","replycounts":226,"ispictopic":1,"bbsid":3405,"bbsname":"艾瑞泽5论坛","postdate":"2016-05-19 11:23:01"},{"topicid":52597703,"title":"E180L\\E200L\\E300L谍照出来，哪款值得买？","lastreplydate":"2016-05-19 19:37:46","postusername":"唱情歌de人","replycounts":32,"ispictopic":1,"bbsid":197,"bbsname":"奔驰E级论坛","postdate":"2016-05-19 12:33:07"},{"topicid":52603212,"title":"博越首撞心疼死我了。","lastreplydate":"2016-05-19 19:32:33","postusername":"爱博越2016","replycounts":83,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 15:31:01"},{"topicid":52591704,"title":"许诺已久的媳妇当车模！欢迎各位来顶顶贴！哈哈","lastreplydate":"2016-05-19 19:49:12","postusername":"六蚊","replycounts":248,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 09:33:26"},{"topicid":52593383,"title":"东博西蒙南帕北K\u2014\u2014妹子和下雨天更配","lastreplydate":"2016-05-19 19:22:51","postusername":"电动车商行","replycounts":29,"ispictopic":1,"bbsid":3589,"bbsname":"博瑞论坛","postdate":"2016-05-19 10:24:59"},{"topicid":52582691,"title":"一汽最老残的设计","lastreplydate":"2016-05-19 19:50:32","postusername":"别动我的凯迪","replycounts":79,"ispictopic":1,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-18 21:41:38"},{"topicid":52583431,"title":"花臂姑娘","lastreplydate":"2016-05-19 19:41:25","postusername":"一些女孩的人们","replycounts":74,"ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-05-18 22:03:09"},{"topicid":52595156,"title":"[原创说车9.5]-再说一些CX-4的信息","lastreplydate":"2016-05-19 19:23:28","postusername":"翼展风凌","replycounts":78,"ispictopic":1,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-19 11:12:03"},{"topicid":52589480,"title":"【认证帖】江淮老车主！喜提瑞风S3 ,申请精华！","lastreplydate":"2016-05-19 19:39:09","postusername":"hhh075800","replycounts":31,"ispictopic":1,"bbsid":3080,"bbsname":"瑞风S3论坛","postdate":"2016-05-19 07:39:07"},{"topicid":52584686,"title":"【美女买车求荐】好像新思域挺适合我的，大家觉得呢？有爆照哦！","lastreplydate":"2016-05-19 19:03:57","postusername":"这是昵称1","replycounts":79,"ispictopic":1,"bbsid":9901135,"bbsname":"新思域论坛","postdate":"2016-05-18 22:39:52"},{"topicid":52595488,"title":"送上航拍森雅R7视频图片·最后附上视频连接·不喜勿喷·","lastreplydate":"2016-05-19 19:09:27","postusername":"江汉爱车人","replycounts":30,"ispictopic":1,"bbsid":3824,"bbsname":"森雅R7论坛","postdate":"2016-05-19 11:21:32"},{"topicid":52584035,"title":"【李叫兽】之GS百米加速，野外半坡，高速80100120的噪音加速视频","lastreplydate":"2016-05-19 19:43:22","postusername":"点坑","replycounts":553,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-18 22:19:59"},{"topicid":52582074,"title":"美不美，看大腿，未成年人谨慎进去","lastreplydate":"2016-05-19 19:43:44","postusername":"坏男孩9","replycounts":72,"ispictopic":1,"bbsid":9901135,"bbsname":"新思域论坛","postdate":"2016-05-18 21:20:18"},{"topicid":52585954,"title":"5.20博越我爱你，博越车机功能简单阐述及问题解答","lastreplydate":"2016-05-19 19:39:33","postusername":"wang9177","replycounts":105,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-18 23:25:09"},{"topicid":52593131,"title":"H7出车祸了","lastreplydate":"2016-05-19 19:49:50","postusername":"裴建成1688","replycounts":116,"ispictopic":1,"bbsid":3074,"bbsname":"哈弗H7论坛","postdate":"2016-05-19 10:18:03"},{"topicid":52581139,"title":"16款一汽版VX提车各功能详细介绍以及认证！","lastreplydate":"2016-05-19 18:12:21","postusername":"dl_sky","replycounts":82,"ispictopic":1,"bbsid":45,"bbsname":"兰德酷路泽论坛","postdate":"2016-05-18 20:45:48"},{"topicid":52580333,"title":"博越车身拉花，腰线贴纸，喜欢拿去，不喜勿喷！","lastreplydate":"2016-05-19 18:06:23","postusername":"zybilqyn","replycounts":72,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-18 20:18:21"},{"topicid":52580960,"title":"城市喧嚷中片刻的宁静  晴天白云一抹蓝 超低清大片来袭~","lastreplydate":"2016-05-19 18:56:12","postusername":"ly158158","replycounts":79,"ispictopic":1,"bbsid":3899,"bbsname":"众泰SR7论坛","postdate":"2016-05-18 20:39:54"},{"topicid":52582233,"title":"提楼兰两个月作业","lastreplydate":"2016-05-19 18:30:57","postusername":"haroun_chen","replycounts":16,"ispictopic":1,"bbsid":2381,"bbsname":"楼兰论坛","postdate":"2016-05-18 21:26:15"},{"topicid":52589515,"title":"自己把宝贝倒车时压了，急需救命","lastreplydate":"2016-05-19 19:51:07","postusername":"虚之无月","replycounts":265,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-19 07:41:57"},{"topicid":52581462,"title":"今天看了CX-4 2.0次顶配","lastreplydate":"2016-05-19 19:40:01","postusername":"半时晴空半时雨","replycounts":134,"ispictopic":1,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-18 20:57:45"},{"topicid":52589362,"title":"全面解析交强险","lastreplydate":"2016-05-19 19:30:18","postusername":"赵1590823","replycounts":50,"ispictopic":1,"bbsid":2334,"bbsname":"众泰T600论坛","postdate":"2016-05-19 07:26:36"},{"topicid":52579709,"title":"终于订车啦！西玛，等你回家！","lastreplydate":"2016-05-19 17:22:30","postusername":"阿勉001255","replycounts":19,"ispictopic":0,"bbsid":3957,"bbsname":"西玛论坛","postdate":"2016-05-18 19:55:01"},{"topicid":52585917,"title":"宁波首台手豪十思\u2014\u2014迟来的作业","lastreplydate":"2016-05-19 19:37:21","postusername":"寇小威","replycounts":257,"ispictopic":1,"bbsid":9901135,"bbsname":"新思域论坛","postdate":"2016-05-18 23:23:47"},{"topicid":52580442,"title":"一个月就三万了！！纠结了。。降这么快的车能买吗。。。。。","lastreplydate":"2016-05-19 19:44:36","postusername":"潜炳光瑞邦水泵","replycounts":75,"ispictopic":0,"bbsid":3989,"bbsname":"凯迪拉克XT5论坛","postdate":"2016-05-18 20:22:17"},{"topicid":52580186,"title":"520提前过，今生今生，只愿意给你专属的守候","lastreplydate":"2016-05-19 18:29:09","postusername":"木马么么哒","replycounts":59,"ispictopic":1,"bbsid":18,"bbsname":"奥迪A6L论坛","postdate":"2016-05-18 20:12:21"},{"topicid":52580525,"title":"迎娶亲爱的小五--苏州博越两驱至尊提车作业","lastreplydate":"2016-05-19 19:45:29","postusername":"szlgy","replycounts":82,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-18 20:25:03"}]
     */

    private ResultBean result;

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public static class ResultBean {
        private int pagecount;
        private int rowcount;
        private int pageindex;
        /**
         * topicid : 52580087
         * title : “威风凛凛”霸气的小三婚车迎娶今天最美的你“新娘”
         * lastreplydate : 2016-05-19 19:50:04
         * postusername : 1m也是钱
         * replycounts : 57
         * ispictopic : 1
         * bbsid : 3080
         * bbsname : 瑞风S3论坛
         * postdate : 2016-05-18 20:08:35
         */

        private List<ListBean> list;

        public int getPagecount() {
            return pagecount;
        }

        public void setPagecount(int pagecount) {
            this.pagecount = pagecount;
        }

        public int getRowcount() {
            return rowcount;
        }

        public void setRowcount(int rowcount) {
            this.rowcount = rowcount;
        }

        public int getPageindex() {
            return pageindex;
        }

        public void setPageindex(int pageindex) {
            this.pageindex = pageindex;
        }

        public List<ListBean> getList() {
            return list;
        }

        public void setList(List<ListBean> list) {
            this.list = list;
        }

        public static class ListBean {
            private int topicid;
            private String title;
            private String lastreplydate;
            private String postusername;
            private int replycounts;
            private int ispictopic;
            private int bbsid;
            private String bbsname;
            private String postdate;

            public int getTopicid() {
                return topicid;
            }

            public void setTopicid(int topicid) {
                this.topicid = topicid;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getLastreplydate() {
                return lastreplydate;
            }

            public void setLastreplydate(String lastreplydate) {
                this.lastreplydate = lastreplydate;
            }

            public String getPostusername() {
                return postusername;
            }

            public void setPostusername(String postusername) {
                this.postusername = postusername;
            }

            public int getReplycounts() {
                return replycounts;
            }

            public void setReplycounts(int replycounts) {
                this.replycounts = replycounts;
            }

            public int getIspictopic() {
                return ispictopic;
            }

            public void setIspictopic(int ispictopic) {
                this.ispictopic = ispictopic;
            }

            public int getBbsid() {
                return bbsid;
            }

            public void setBbsid(int bbsid) {
                this.bbsid = bbsid;
            }

            public String getBbsname() {
                return bbsname;
            }

            public void setBbsname(String bbsname) {
                this.bbsname = bbsname;
            }

            public String getPostdate() {
                return postdate;
            }

            public void setPostdate(String postdate) {
                this.postdate = postdate;
            }
        }
    }
}
