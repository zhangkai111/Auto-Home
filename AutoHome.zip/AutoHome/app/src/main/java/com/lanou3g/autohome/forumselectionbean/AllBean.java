package com.lanou3g.autohome.forumselectionbean;

import java.util.List;

/**
 * Created by dllo on 16/5/12.
 */
public class AllBean {

    /**
     * message :
     * returncode : 0
     * result : {"pageindex":1,"pagecount":1552,"rowcount":46560,"list":[{"topicid":51856191,"title":"砚式石盐槽密布 环中国自驾游儋州","lastreplydate":"10秒前","postusername":"熬夜人","replycounts":102,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g6/M06/66/94/userphotos/2016/04/27/12/240180_wKgH3FcgOWOAMqfKAAE0v97mvfM423.jpg","topictype":"精","views":24628,"postmemberid":0,"imgurl":"","bbsid":771,"bbstype":"c","bbsname":"华南游记628季"},{"topicid":52202114,"title":"对比GL8略有优势 提艾力绅简单分享","lastreplydate":"2秒前","postusername":"小xin囧","replycounts":400,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g18/M03/75/16/userphotos/2016/05/08/18/240180_wKgH2VcvFciAGpUBAAFC4pxHeP0505.jpg","topictype":"精","views":130106,"postmemberid":0,"imgurl":"","bbsid":2565,"bbstype":"c","bbsname":"汇买车14375季"},{"topicid":51528570,"title":"开起来得心应手 一汽丰田RAV4用车","lastreplydate":"1分钟前","postusername":"去往北极的天使YXG","replycounts":234,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g23/M12/3B/84/userphotos/2016/04/16/21/240180_wKgFXFcSQiOASEXPAAEoee3D1ic127.jpg","topictype":"精","views":48259,"postmemberid":0,"imgurl":"","bbsid":770,"bbstype":"c","bbsname":"行车点评5629季"},{"topicid":52313431,"title":"惊艳登场 汽车之家MODEL X国内首拍","lastreplydate":"3分钟前","postusername":"lican0718","replycounts":110,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g22/M0C/5B/B8/userphotos/2016/05/11/15/240180_wKgFVlcy4pWAZSmeAAElzIYYsrw503.jpg","topictype":"精","views":49899,"postmemberid":0,"imgurl":"","bbsid":2664,"bbstype":"c","bbsname":"原创大片787季"},{"topicid":51740850,"title":"畅游青山绿水间 周末百里峡自驾游","lastreplydate":"4分钟前","postusername":"鹤舞蝶依","replycounts":217,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g10/M0C/71/02/userphotos/2016/05/05/10/240180_wKjBzVcqqbuAPYDKAAEcV6GSi0g459.jpg","topictype":"精","views":39808,"postmemberid":0,"imgurl":"","bbsid":100002,"bbstype":"a","bbsname":"华北游记1024季"},{"topicid":51499993,"title":"将运动进行到底 科鲁兹1.6L告别秀","lastreplydate":"6分钟前","postusername":"qinfeif","replycounts":131,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g13/M03/59/99/userphotos/2016/04/17/16/240180_wKjBylcTTZSAejgpAAEy0n242c0882.jpg","topictype":"精","views":37686,"postmemberid":0,"imgurl":"","bbsid":657,"bbstype":"c","bbsname":"行车点评5628季"},{"topicid":52276889,"title":"难忘惊鸿一瞥 小野猫与凯迪拉克CT6","lastreplydate":"33秒前","postusername":"专业潜水砖家","replycounts":1229,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g5/M02/78/BE/userphotos/2016/05/11/15/240180_wKjB0lcy2eGABaNEAAEdrpCXxYc057.jpg","topictype":"精","views":298078,"postmemberid":0,"imgurl":"","bbsid":3802,"bbstype":"c","bbsname":"原创大片786季"},{"topicid":52134093,"title":"你不来我不老 广东至云南自驾之旅","lastreplydate":"13分钟前","postusername":"simplywang","replycounts":193,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g5/M01/73/E0/userphotos/2016/05/07/00/240180_wKgH21cswHOAWiK7AAE5kARXXTA402.jpg","topictype":"精","views":18249,"postmemberid":0,"imgurl":"","bbsid":530,"bbstype":"c","bbsname":"西南游记2610季"},{"topicid":51828192,"title":"综合考量之选 谈创酷1.4T满月心得","lastreplydate":"28秒前","postusername":"时速350","replycounts":87,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g15/M09/69/5D/userphotos/2016/04/28/16/240180_wKgH1lchw_mAcK5fAAEl0vjV2MI204.jpg","topictype":"精","views":21784,"postmemberid":0,"imgurl":"","bbsid":3335,"bbstype":"c","bbsname":"行车点评5627季"},{"topicid":52050586,"title":"物有所值之选 浅谈昂科威28T豪华型","lastreplydate":"1分钟前","postusername":"Longbow_Apache","replycounts":106,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g6/M14/70/40/userphotos/2016/05/04/17/240180_wKgH3FcpvmeAGK-OAAEjOS0HcMg276.jpg","topictype":"精","views":33991,"postmemberid":0,"imgurl":"","bbsid":3554,"bbstype":"c","bbsname":"行车点评5626季"},{"topicid":51894122,"title":"优秀的居家车 思铂睿2.0L选购心路","lastreplydate":"2分钟前","postusername":"chan2000","replycounts":152,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g4/M04/69/59/userphotos/2016/04/30/00/240180_wKgHy1cjh9aAQMy9AAEtz-owBZs555.jpg","topictype":"精","views":48593,"postmemberid":0,"imgurl":"","bbsid":859,"bbstype":"c","bbsname":"行车点评5625季"},{"topicid":51724369,"title":"一场选车拉力赛 以翼虎2.0T画句号","lastreplydate":"57分钟前","postusername":"dictionary1980","replycounts":57,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g10/M05/62/72/userphotos/2016/04/24/16/240180_wKjBzVcciDyAJVptAAFDRC4TCyo129.jpg","topictype":"精","views":11643,"postmemberid":0,"imgurl":"","bbsid":2863,"bbstype":"c","bbsname":"汇买车14374季"},{"topicid":51821529,"title":"航空爱好者的盛会 记佛罗里达航展","lastreplydate":"37分钟前","postusername":"海外思华","replycounts":37,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g17/M0C/62/29/userphotos/2016/04/27/16/240180_wKgH2FcgfdiAf5y6AAE6-3wyy68589.jpg","topictype":"精","views":6228,"postmemberid":0,"imgurl":"","bbsid":200223,"bbstype":"o","bbsname":"海外游记2050季"},{"topicid":51820881,"title":"人生若只如初见 奔驰GLC 300提车记","lastreplydate":"15分钟前","postusername":"xiaoxiyoumei","replycounts":187,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g16/M0D/66/B5/userphotos/2016/04/27/15/240180_wKjBx1cgb0qAEONcAAEbUl8SSnI437.jpg","topictype":"精","views":69759,"postmemberid":0,"imgurl":"","bbsid":3862,"bbstype":"c","bbsname":"汇买车14373季"},{"topicid":51858508,"title":"为老婆圆儿时梦想 游希腊圣托里尼","lastreplydate":"2分钟前","postusername":"artofspeedracing","replycounts":147,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g13/M0A/69/7B/userphotos/2016/04/29/11/240180_wKjBylci2JWARkQeAAE57PNf3pk697.jpg","topictype":"精","views":41387,"postmemberid":0,"imgurl":"","bbsid":200042,"bbstype":"o","bbsname":"海外游记2049季"},{"topicid":51821133,"title":"外观控的选择 威朗20T精英型提车","lastreplydate":"53分钟前","postusername":"leonki","replycounts":154,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g7/M03/66/65/userphotos/2016/04/27/16/240180_wKjB0FcgeGmACPHaAAEh5iEs76o700.jpg","topictype":"精","views":22788,"postmemberid":0,"imgurl":"","bbsid":3751,"bbstype":"c","bbsname":"汇买车14372季"},{"topicid":51858234,"title":"亲自体验最重要 艾瑞泽5 1.5L提车","lastreplydate":"2分钟前","postusername":"科技楼卧龙","replycounts":155,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g19/M06/4B/C1/userphotos/2016/04/29/15/240180_wKgFWFcjE5WAQSoPAAExGJxDAfw646.jpg","topictype":"精","views":37437,"postmemberid":0,"imgurl":"","bbsid":3405,"bbstype":"c","bbsname":"汇买车14371季"},{"topicid":51850434,"title":"消除异味 迈腾空调蒸发仓清洗报告","lastreplydate":"1分钟前","postusername":"Chingle6988","replycounts":53,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g4/M0A/67/00/userphotos/2016/04/28/11/240180_wKgHy1chg0WAY6VCAAEkKr8Ak9U853.jpg","topictype":"精","views":13574,"postmemberid":0,"imgurl":"","bbsid":100002,"bbstype":"a","bbsname":"养车有道713季"},{"topicid":52221161,"title":"赏落樱缤纷之美 日本本州岛六日游","lastreplydate":"3分钟前","postusername":"laolang991","replycounts":138,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g16/M0E/78/96/userphotos/2016/05/11/09/240180_wKjBx1cyizKAEHPrAAE1bYXeUZw670.jpg","topictype":"精","views":27729,"postmemberid":0,"imgurl":"","bbsid":3185,"bbstype":"c","bbsname":"海外游记2048季"},{"topicid":52223442,"title":"指向精准外观萌 入手标致3008 2.0L","lastreplydate":"49分钟前","postusername":"六大人","replycounts":84,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g18/M13/78/EC/userphotos/2016/05/11/16/240180_wKgH6Fcy6uKADE9mAAEvk___3Mw737.jpg","topictype":"精","views":10314,"postmemberid":0,"imgurl":"","bbsid":2619,"bbstype":"c","bbsname":"汇买车14370季"},{"topicid":51894282,"title":"加速换挡很平顺 长安CS75提车分享","lastreplydate":"1小时前","postusername":"颜一一一","replycounts":106,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g17/M01/65/23/userphotos/2016/04/30/12/240180_wKjBxlckNc2AKP-RAAEuKFkD1M0004.jpg","topictype":"精","views":15015,"postmemberid":0,"imgurl":"","bbsid":3204,"bbstype":"c","bbsname":"汇买车14369季"},{"topicid":51816983,"title":"绝赞外观进化 凯迪拉克ATS-L写真集","lastreplydate":"36分钟前","postusername":"寂寞赛道","replycounts":52,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g13/M03/66/DD/userphotos/2016/04/27/13/240180_wKjBylcgTOKANpfYAAEoMY8MrKI067.jpg","topictype":"精","views":13022,"postmemberid":0,"imgurl":"","bbsid":3207,"bbstype":"c","bbsname":"原创大片785季"},{"topicid":51939417,"title":"门面焕新很重要 逍客体验水晶镀膜","lastreplydate":"34分钟前","postusername":"我还没晕","replycounts":97,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g8/M0C/64/A8/userphotos/2016/05/01/16/240180_wKjBz1cluS2AGYv7AAEb4ScQbKA111.jpg","topictype":"精","views":9569,"postmemberid":0,"imgurl":"","bbsid":564,"bbstype":"c","bbsname":"养车有道712季"},{"topicid":51820636,"title":"无需PS的景致 新疆奎屯小镇随拍集","lastreplydate":"6分钟前","postusername":"1005316118","replycounts":117,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g19/M00/48/B7/userphotos/2016/04/27/13/240180_wKjBxFcgSuyAbJLFAAE_hekl8uQ610.jpg","topictype":"精","views":5589,"postmemberid":0,"imgurl":"","bbsid":3395,"bbstype":"c","bbsname":"西北游记923季"},{"topicid":51861629,"title":"用时半天 根除二手皇冠车内塑料味","lastreplydate":"2分钟前","postusername":"yuanguojian","replycounts":187,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g21/M11/4B/5A/userphotos/2016/04/29/17/240180_wKgFVVcjLpeAadFvAAFLMF8AuwM933.jpg","topictype":"精","views":38375,"postmemberid":0,"imgurl":"","bbsid":882,"bbstype":"c","bbsname":"养车有道711季"},{"topicid":51934292,"title":"省下工时费 DIY更换空调/空气滤芯","lastreplydate":"2小时前","postusername":"已存在的用户名","replycounts":21,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g17/M03/66/4F/userphotos/2016/05/01/12/240180_wKjBxlclixqAEeyhAAEsufuY1QI039.jpg","topictype":"精","views":3848,"postmemberid":0,"imgurl":"","bbsid":875,"bbstype":"c","bbsname":"养车有道710季"},{"topicid":51638821,"title":"只为那骑士精神 哈雷重机古巴之旅","lastreplydate":"4分钟前","postusername":"我行我速dobedo","replycounts":102,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g5/M05/66/F0/userphotos/2016/04/27/12/240180_wKgH21cgRUGALq50AAEiVJOTjQE411.jpg","topictype":"精","views":19469,"postmemberid":0,"imgurl":"","bbsid":200063,"bbstype":"o","bbsname":"摩友天地230季"},{"topicid":52212113,"title":"到底值不值？比亚迪唐2.0T用车心得","lastreplydate":"33秒前","postusername":"柏老师家的李同学","replycounts":165,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g6/M08/77/45/userphotos/2016/05/10/15/240180_wKgHzVcxijKABqR7AAEwNB3pyXI135.jpg","topictype":"精","views":28191,"postmemberid":0,"imgurl":"","bbsid":3430,"bbstype":"c","bbsname":"行车点评5624季"},{"topicid":52146718,"title":"云朵上的羌寨 自驾畅游汶川萝卜寨","lastreplydate":"3分钟前","postusername":"暗香蘭露","replycounts":77,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g15/M0A/72/4A/userphotos/2016/05/07/23/240180_wKgH5VcuDY2AFHvBAAEazTuxZrs511.jpg","topictype":"精","views":5422,"postmemberid":0,"imgurl":"","bbsid":100025,"bbstype":"a","bbsname":"西南游记2609季"},{"topicid":51874629,"title":"爱车要勤保养 大迈X5 1.5T首保分享","lastreplydate":"1小时前","postusername":"liyan8695","replycounts":97,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g20/M13/48/DA/userphotos/2016/04/27/12/240180_wKgFVFcgRx6ADlNRAAE6PsfgM-M547.jpg","topictype":"精","views":5885,"postmemberid":0,"imgurl":"","bbsid":3793,"bbstype":"c","bbsname":"养车有道709季"}]}
     */

    private String message;
    private int returncode;
    /**
     * pageindex : 1
     * pagecount : 1552
     * rowcount : 46560
     * list : [{"topicid":51856191,"title":"砚式石盐槽密布 环中国自驾游儋州","lastreplydate":"10秒前","postusername":"熬夜人","replycounts":102,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g6/M06/66/94/userphotos/2016/04/27/12/240180_wKgH3FcgOWOAMqfKAAE0v97mvfM423.jpg","topictype":"精","views":24628,"postmemberid":0,"imgurl":"","bbsid":771,"bbstype":"c","bbsname":"华南游记628季"},{"topicid":52202114,"title":"对比GL8略有优势 提艾力绅简单分享","lastreplydate":"2秒前","postusername":"小xin囧","replycounts":400,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g18/M03/75/16/userphotos/2016/05/08/18/240180_wKgH2VcvFciAGpUBAAFC4pxHeP0505.jpg","topictype":"精","views":130106,"postmemberid":0,"imgurl":"","bbsid":2565,"bbstype":"c","bbsname":"汇买车14375季"},{"topicid":51528570,"title":"开起来得心应手 一汽丰田RAV4用车","lastreplydate":"1分钟前","postusername":"去往北极的天使YXG","replycounts":234,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g23/M12/3B/84/userphotos/2016/04/16/21/240180_wKgFXFcSQiOASEXPAAEoee3D1ic127.jpg","topictype":"精","views":48259,"postmemberid":0,"imgurl":"","bbsid":770,"bbstype":"c","bbsname":"行车点评5629季"},{"topicid":52313431,"title":"惊艳登场 汽车之家MODEL X国内首拍","lastreplydate":"3分钟前","postusername":"lican0718","replycounts":110,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g22/M0C/5B/B8/userphotos/2016/05/11/15/240180_wKgFVlcy4pWAZSmeAAElzIYYsrw503.jpg","topictype":"精","views":49899,"postmemberid":0,"imgurl":"","bbsid":2664,"bbstype":"c","bbsname":"原创大片787季"},{"topicid":51740850,"title":"畅游青山绿水间 周末百里峡自驾游","lastreplydate":"4分钟前","postusername":"鹤舞蝶依","replycounts":217,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g10/M0C/71/02/userphotos/2016/05/05/10/240180_wKjBzVcqqbuAPYDKAAEcV6GSi0g459.jpg","topictype":"精","views":39808,"postmemberid":0,"imgurl":"","bbsid":100002,"bbstype":"a","bbsname":"华北游记1024季"},{"topicid":51499993,"title":"将运动进行到底 科鲁兹1.6L告别秀","lastreplydate":"6分钟前","postusername":"qinfeif","replycounts":131,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g13/M03/59/99/userphotos/2016/04/17/16/240180_wKjBylcTTZSAejgpAAEy0n242c0882.jpg","topictype":"精","views":37686,"postmemberid":0,"imgurl":"","bbsid":657,"bbstype":"c","bbsname":"行车点评5628季"},{"topicid":52276889,"title":"难忘惊鸿一瞥 小野猫与凯迪拉克CT6","lastreplydate":"33秒前","postusername":"专业潜水砖家","replycounts":1229,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g5/M02/78/BE/userphotos/2016/05/11/15/240180_wKjB0lcy2eGABaNEAAEdrpCXxYc057.jpg","topictype":"精","views":298078,"postmemberid":0,"imgurl":"","bbsid":3802,"bbstype":"c","bbsname":"原创大片786季"},{"topicid":52134093,"title":"你不来我不老 广东至云南自驾之旅","lastreplydate":"13分钟前","postusername":"simplywang","replycounts":193,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g5/M01/73/E0/userphotos/2016/05/07/00/240180_wKgH21cswHOAWiK7AAE5kARXXTA402.jpg","topictype":"精","views":18249,"postmemberid":0,"imgurl":"","bbsid":530,"bbstype":"c","bbsname":"西南游记2610季"},{"topicid":51828192,"title":"综合考量之选 谈创酷1.4T满月心得","lastreplydate":"28秒前","postusername":"时速350","replycounts":87,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g15/M09/69/5D/userphotos/2016/04/28/16/240180_wKgH1lchw_mAcK5fAAEl0vjV2MI204.jpg","topictype":"精","views":21784,"postmemberid":0,"imgurl":"","bbsid":3335,"bbstype":"c","bbsname":"行车点评5627季"},{"topicid":52050586,"title":"物有所值之选 浅谈昂科威28T豪华型","lastreplydate":"1分钟前","postusername":"Longbow_Apache","replycounts":106,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g6/M14/70/40/userphotos/2016/05/04/17/240180_wKgH3FcpvmeAGK-OAAEjOS0HcMg276.jpg","topictype":"精","views":33991,"postmemberid":0,"imgurl":"","bbsid":3554,"bbstype":"c","bbsname":"行车点评5626季"},{"topicid":51894122,"title":"优秀的居家车 思铂睿2.0L选购心路","lastreplydate":"2分钟前","postusername":"chan2000","replycounts":152,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g4/M04/69/59/userphotos/2016/04/30/00/240180_wKgHy1cjh9aAQMy9AAEtz-owBZs555.jpg","topictype":"精","views":48593,"postmemberid":0,"imgurl":"","bbsid":859,"bbstype":"c","bbsname":"行车点评5625季"},{"topicid":51724369,"title":"一场选车拉力赛 以翼虎2.0T画句号","lastreplydate":"57分钟前","postusername":"dictionary1980","replycounts":57,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g10/M05/62/72/userphotos/2016/04/24/16/240180_wKjBzVcciDyAJVptAAFDRC4TCyo129.jpg","topictype":"精","views":11643,"postmemberid":0,"imgurl":"","bbsid":2863,"bbstype":"c","bbsname":"汇买车14374季"},{"topicid":51821529,"title":"航空爱好者的盛会 记佛罗里达航展","lastreplydate":"37分钟前","postusername":"海外思华","replycounts":37,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g17/M0C/62/29/userphotos/2016/04/27/16/240180_wKgH2FcgfdiAf5y6AAE6-3wyy68589.jpg","topictype":"精","views":6228,"postmemberid":0,"imgurl":"","bbsid":200223,"bbstype":"o","bbsname":"海外游记2050季"},{"topicid":51820881,"title":"人生若只如初见 奔驰GLC 300提车记","lastreplydate":"15分钟前","postusername":"xiaoxiyoumei","replycounts":187,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g16/M0D/66/B5/userphotos/2016/04/27/15/240180_wKjBx1cgb0qAEONcAAEbUl8SSnI437.jpg","topictype":"精","views":69759,"postmemberid":0,"imgurl":"","bbsid":3862,"bbstype":"c","bbsname":"汇买车14373季"},{"topicid":51858508,"title":"为老婆圆儿时梦想 游希腊圣托里尼","lastreplydate":"2分钟前","postusername":"artofspeedracing","replycounts":147,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g13/M0A/69/7B/userphotos/2016/04/29/11/240180_wKjBylci2JWARkQeAAE57PNf3pk697.jpg","topictype":"精","views":41387,"postmemberid":0,"imgurl":"","bbsid":200042,"bbstype":"o","bbsname":"海外游记2049季"},{"topicid":51821133,"title":"外观控的选择 威朗20T精英型提车","lastreplydate":"53分钟前","postusername":"leonki","replycounts":154,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g7/M03/66/65/userphotos/2016/04/27/16/240180_wKjB0FcgeGmACPHaAAEh5iEs76o700.jpg","topictype":"精","views":22788,"postmemberid":0,"imgurl":"","bbsid":3751,"bbstype":"c","bbsname":"汇买车14372季"},{"topicid":51858234,"title":"亲自体验最重要 艾瑞泽5 1.5L提车","lastreplydate":"2分钟前","postusername":"科技楼卧龙","replycounts":155,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g19/M06/4B/C1/userphotos/2016/04/29/15/240180_wKgFWFcjE5WAQSoPAAExGJxDAfw646.jpg","topictype":"精","views":37437,"postmemberid":0,"imgurl":"","bbsid":3405,"bbstype":"c","bbsname":"汇买车14371季"},{"topicid":51850434,"title":"消除异味 迈腾空调蒸发仓清洗报告","lastreplydate":"1分钟前","postusername":"Chingle6988","replycounts":53,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g4/M0A/67/00/userphotos/2016/04/28/11/240180_wKgHy1chg0WAY6VCAAEkKr8Ak9U853.jpg","topictype":"精","views":13574,"postmemberid":0,"imgurl":"","bbsid":100002,"bbstype":"a","bbsname":"养车有道713季"},{"topicid":52221161,"title":"赏落樱缤纷之美 日本本州岛六日游","lastreplydate":"3分钟前","postusername":"laolang991","replycounts":138,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g16/M0E/78/96/userphotos/2016/05/11/09/240180_wKjBx1cyizKAEHPrAAE1bYXeUZw670.jpg","topictype":"精","views":27729,"postmemberid":0,"imgurl":"","bbsid":3185,"bbstype":"c","bbsname":"海外游记2048季"},{"topicid":52223442,"title":"指向精准外观萌 入手标致3008 2.0L","lastreplydate":"49分钟前","postusername":"六大人","replycounts":84,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g18/M13/78/EC/userphotos/2016/05/11/16/240180_wKgH6Fcy6uKADE9mAAEvk___3Mw737.jpg","topictype":"精","views":10314,"postmemberid":0,"imgurl":"","bbsid":2619,"bbstype":"c","bbsname":"汇买车14370季"},{"topicid":51894282,"title":"加速换挡很平顺 长安CS75提车分享","lastreplydate":"1小时前","postusername":"颜一一一","replycounts":106,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g17/M01/65/23/userphotos/2016/04/30/12/240180_wKjBxlckNc2AKP-RAAEuKFkD1M0004.jpg","topictype":"精","views":15015,"postmemberid":0,"imgurl":"","bbsid":3204,"bbstype":"c","bbsname":"汇买车14369季"},{"topicid":51816983,"title":"绝赞外观进化 凯迪拉克ATS-L写真集","lastreplydate":"36分钟前","postusername":"寂寞赛道","replycounts":52,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g13/M03/66/DD/userphotos/2016/04/27/13/240180_wKjBylcgTOKANpfYAAEoMY8MrKI067.jpg","topictype":"精","views":13022,"postmemberid":0,"imgurl":"","bbsid":3207,"bbstype":"c","bbsname":"原创大片785季"},{"topicid":51939417,"title":"门面焕新很重要 逍客体验水晶镀膜","lastreplydate":"34分钟前","postusername":"我还没晕","replycounts":97,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g8/M0C/64/A8/userphotos/2016/05/01/16/240180_wKjBz1cluS2AGYv7AAEb4ScQbKA111.jpg","topictype":"精","views":9569,"postmemberid":0,"imgurl":"","bbsid":564,"bbstype":"c","bbsname":"养车有道712季"},{"topicid":51820636,"title":"无需PS的景致 新疆奎屯小镇随拍集","lastreplydate":"6分钟前","postusername":"1005316118","replycounts":117,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g19/M00/48/B7/userphotos/2016/04/27/13/240180_wKjBxFcgSuyAbJLFAAE_hekl8uQ610.jpg","topictype":"精","views":5589,"postmemberid":0,"imgurl":"","bbsid":3395,"bbstype":"c","bbsname":"西北游记923季"},{"topicid":51861629,"title":"用时半天 根除二手皇冠车内塑料味","lastreplydate":"2分钟前","postusername":"yuanguojian","replycounts":187,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g21/M11/4B/5A/userphotos/2016/04/29/17/240180_wKgFVVcjLpeAadFvAAFLMF8AuwM933.jpg","topictype":"精","views":38375,"postmemberid":0,"imgurl":"","bbsid":882,"bbstype":"c","bbsname":"养车有道711季"},{"topicid":51934292,"title":"省下工时费 DIY更换空调/空气滤芯","lastreplydate":"2小时前","postusername":"已存在的用户名","replycounts":21,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g17/M03/66/4F/userphotos/2016/05/01/12/240180_wKjBxlclixqAEeyhAAEsufuY1QI039.jpg","topictype":"精","views":3848,"postmemberid":0,"imgurl":"","bbsid":875,"bbstype":"c","bbsname":"养车有道710季"},{"topicid":51638821,"title":"只为那骑士精神 哈雷重机古巴之旅","lastreplydate":"4分钟前","postusername":"我行我速dobedo","replycounts":102,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g5/M05/66/F0/userphotos/2016/04/27/12/240180_wKgH21cgRUGALq50AAEiVJOTjQE411.jpg","topictype":"精","views":19469,"postmemberid":0,"imgurl":"","bbsid":200063,"bbstype":"o","bbsname":"摩友天地230季"},{"topicid":52212113,"title":"到底值不值？比亚迪唐2.0T用车心得","lastreplydate":"33秒前","postusername":"柏老师家的李同学","replycounts":165,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g6/M08/77/45/userphotos/2016/05/10/15/240180_wKgHzVcxijKABqR7AAEwNB3pyXI135.jpg","topictype":"精","views":28191,"postmemberid":0,"imgurl":"","bbsid":3430,"bbstype":"c","bbsname":"行车点评5624季"},{"topicid":52146718,"title":"云朵上的羌寨 自驾畅游汶川萝卜寨","lastreplydate":"3分钟前","postusername":"暗香蘭露","replycounts":77,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g15/M0A/72/4A/userphotos/2016/05/07/23/240180_wKgH5VcuDY2AFHvBAAEazTuxZrs511.jpg","topictype":"精","views":5422,"postmemberid":0,"imgurl":"","bbsid":100025,"bbstype":"a","bbsname":"西南游记2609季"},{"topicid":51874629,"title":"爱车要勤保养 大迈X5 1.5T首保分享","lastreplydate":"1小时前","postusername":"liyan8695","replycounts":97,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g20/M13/48/DA/userphotos/2016/04/27/12/240180_wKgFVFcgRx6ADlNRAAE6PsfgM-M547.jpg","topictype":"精","views":5885,"postmemberid":0,"imgurl":"","bbsid":3793,"bbstype":"c","bbsname":"养车有道709季"}]
     */

    private ResultBean result;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public static class ResultBean {
        private int pageindex;
        private int pagecount;
        private int rowcount;
        /**
         * topicid : 51856191
         * title : 砚式石盐槽密布 环中国自驾游儋州
         * lastreplydate : 10秒前
         * postusername : 熬夜人
         * replycounts : 102
         * isclosed : 0
         * bigpic :
         * smallpic : http://club2.autoimg.cn/album/g6/M06/66/94/userphotos/2016/04/27/12/240180_wKgH3FcgOWOAMqfKAAE0v97mvfM423.jpg
         * topictype : 精
         * views : 24628
         * postmemberid : 0
         * imgurl :
         * bbsid : 771
         * bbstype : c
         * bbsname : 华南游记628季
         */

        private List<ListBean> list;

        public int getPageindex() {
            return pageindex;
        }

        public void setPageindex(int pageindex) {
            this.pageindex = pageindex;
        }

        public int getPagecount() {
            return pagecount;
        }

        public void setPagecount(int pagecount) {
            this.pagecount = pagecount;
        }

        public int getRowcount() {
            return rowcount;
        }

        public void setRowcount(int rowcount) {
            this.rowcount = rowcount;
        }

        public List<ListBean> getList() {
            return list;
        }

        public void setList(List<ListBean> list) {
            this.list = list;
        }

        public static class ListBean {
            private int topicid;
            private String title;
            private String lastreplydate;
            private String postusername;
            private int replycounts;
            private int isclosed;
            private String bigpic;
            private String smallpic;
            private String topictype;
            private int views;
            private int postmemberid;
            private String imgurl;
            private int bbsid;
            private String bbstype;
            private String bbsname;

            public int getTopicid() {
                return topicid;
            }

            public void setTopicid(int topicid) {
                this.topicid = topicid;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getLastreplydate() {
                return lastreplydate;
            }

            public void setLastreplydate(String lastreplydate) {
                this.lastreplydate = lastreplydate;
            }

            public String getPostusername() {
                return postusername;
            }

            public void setPostusername(String postusername) {
                this.postusername = postusername;
            }

            public int getReplycounts() {
                return replycounts;
            }

            public void setReplycounts(int replycounts) {
                this.replycounts = replycounts;
            }

            public int getIsclosed() {
                return isclosed;
            }

            public void setIsclosed(int isclosed) {
                this.isclosed = isclosed;
            }

            public String getBigpic() {
                return bigpic;
            }

            public void setBigpic(String bigpic) {
                this.bigpic = bigpic;
            }

            public String getSmallpic() {
                return smallpic;
            }

            public void setSmallpic(String smallpic) {
                this.smallpic = smallpic;
            }

            public String getTopictype() {
                return topictype;
            }

            public void setTopictype(String topictype) {
                this.topictype = topictype;
            }

            public int getViews() {
                return views;
            }

            public void setViews(int views) {
                this.views = views;
            }

            public int getPostmemberid() {
                return postmemberid;
            }

            public void setPostmemberid(int postmemberid) {
                this.postmemberid = postmemberid;
            }

            public String getImgurl() {
                return imgurl;
            }

            public void setImgurl(String imgurl) {
                this.imgurl = imgurl;
            }

            public int getBbsid() {
                return bbsid;
            }

            public void setBbsid(int bbsid) {
                this.bbsid = bbsid;
            }

            public String getBbstype() {
                return bbstype;
            }

            public void setBbstype(String bbstype) {
                this.bbstype = bbstype;
            }

            public String getBbsname() {
                return bbsname;
            }

            public void setBbsname(String bbsname) {
                this.bbsname = bbsname;
            }
        }
    }
}
