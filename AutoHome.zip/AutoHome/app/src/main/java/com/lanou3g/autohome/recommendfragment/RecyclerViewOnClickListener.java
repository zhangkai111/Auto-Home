package com.lanou3g.autohome.recommendfragment;

/**
 * Created by dllo on 16/5/11.
 */
public interface RecyclerViewOnClickListener {
        void onClick(int ids);
}
