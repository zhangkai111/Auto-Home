package com.lanou3g.autohome.recommendfragment;

import android.view.View;

import com.lanou3g.autohome.R;
import com.lanou3g.autohome.base.BaseFragment;

/**
 * Created by dllo on 16/5/9.
 */
public class Price extends BaseFragment {
    @Override
    public int initLayout() {
        return R.layout.recommend_price;
    }

    @Override
    public void initView() {

    }

    @Override
    public void initData() {

    }
}
