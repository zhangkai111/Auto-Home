package com.lanou3g.autohome.recommendbean;

import java.util.List;

/**
 * Created by dllo on 16/5/13.
 */
public class UseCarBean {


    /**
     * rowcount : 1569
     * isloadmore : true
     * headlineinfo : {}
     * focusimg : []
     * newslist : [{"dbid":0,"id":888410,"title":"手机定损？谈App对移动定损带来的变革","mediatype":0,"type":"用车养车","time":"2016-05-12","intacttime":"2016/5/12 20:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g22/M08/5C/D6/400x300_0_autohomecar__wKgFVlc0LX-AS22QAAFvDrXjku8664.jpg","replycount":53,"pagecount":1,"jumppage":1,"lasttime":"20160512200000888410","newstype":0,"updatetime":"20160513145714","coverimages":[]},{"dbid":0,"id":888427,"title":"只动口不动手！百度车辆语音控制新方案","mediatype":0,"type":"用车养车","time":"2016-05-12","intacttime":"2016/5/12 1:34:14","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g7/M03/79/61/400x300_0_autohomecar__wKgHzlczZTiAS3pjAAEhNKe72iM965.jpg","replycount":201,"pagecount":1,"jumppage":1,"lasttime":"20160512013414888427","newstype":0,"updatetime":"20160512091549","coverimages":[]},{"dbid":0,"id":888428,"title":"携手搜狗导航 友衷发布AutoIO超能仪表","mediatype":0,"type":"用车养车","time":"2016-05-12","intacttime":"2016/5/12 0:44:15","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g8/M0E/7D/36/400x300_0_autohomecar__wKgH3lcz9QuAPjjDAAGZ7W8Qcm4716.jpg","replycount":23,"pagecount":1,"jumppage":1,"lasttime":"20160512004415888428","newstype":0,"updatetime":"20160512111444","coverimages":[]},{"dbid":0,"id":888152,"title":"春天洗个\u201c毛\u201d 汽车水箱清洗大作战","mediatype":0,"type":"用车养车","time":"2016-05-12","intacttime":"2016/5/12 0:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g20/M12/59/22/400x300_0_autohomecar__wKgFWVcwZA-AJOajAAH8srI0l8A028.jpg","replycount":354,"pagecount":1,"jumppage":1,"lasttime":"20160512000000888152","newstype":0,"updatetime":"20160512093019","coverimages":[]},{"dbid":0,"id":888417,"title":"四维图新在沪展示高精度地图和趣驾系统","mediatype":0,"type":"用车养车","time":"2016-05-11","intacttime":"2016/5/11 20:57:37","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g13/M08/7A/38/400x300_0_autohomecar__wKjBylcz6SWAMUjaAAFd6xsNv7s352.jpg","replycount":15,"pagecount":1,"jumppage":1,"lasttime":"20160511205737888417","newstype":0,"updatetime":"20160512102825","coverimages":[]},{"dbid":0,"id":888251,"title":"功能基本齐全 体验昕动多媒体和记录仪","mediatype":0,"type":"用车养车","time":"2016-05-10","intacttime":"2016/5/10 0:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g18/M0E/75/FE/400x300_0_autohomecar__wKjBxVcwWjWAXNP1AAF7US_BvS4391.jpg","replycount":94,"pagecount":3,"jumppage":1,"lasttime":"20160510000000888251","newstype":0,"updatetime":"20160510000200","coverimages":[]},{"dbid":0,"id":888335,"title":"您怎么看？草原天路变收费公路合理吗","mediatype":0,"type":"用车养车","time":"2016-05-09","intacttime":"2016/5/9 20:30:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M02/77/74/400x300_0_autohomecar__wKgH5FcwRN-ALvUTAAGnVwEfP_E812.jpg","replycount":1354,"pagecount":1,"jumppage":1,"lasttime":"20160509203000888335","newstype":0,"updatetime":"20160510073439","coverimages":[]},{"dbid":0,"id":888310,"title":"湿地驾驶更安全 玛吉斯发布全新HP5轮胎","mediatype":10,"type":"用车养车","time":"2016-05-08","intacttime":"2016/5/8 23:02:02","indexdetail":"http://www2.autoimg.cn/newsdfs/g20/M04/58/12/400x300_0_autohomecar__wKgFWVcvTquASkroAAC2I_m8cHM012.jpg㊣http://www2.autoimg.cn/newsdfs/g15/M03/76/FA/400x300_0_autohomecar__wKjByFcvVdyAd8ydAACNcUQ54to926.jpg㊣http://www2.autoimg.cn/newsdfs/g8/M01/78/99/400x300_0_autohomecar__wKgHz1cvTyKAcgOdAACkvAq5L4s583.jpg","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M0A/57/5F/400x300_0_autohomecar__wKjBw1cvTqmAUXT3AAFnI1UIjdY660.jpg","replycount":145,"pagecount":1,"jumppage":1,"lasttime":"20160508230202888310","newstype":0,"updatetime":"20160508235610","coverimages":[]},{"dbid":0,"id":888218,"title":"空调异味怎么办？编辑体验三种除味方法","mediatype":0,"type":"用车养车","time":"2016-05-07","intacttime":"2016/5/7 20:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g14/M13/70/51/400x300_0_autohomecar__wKjByVcq3aqAct5WAAGYzRuEMeM561.jpg","replycount":424,"pagecount":2,"jumppage":1,"lasttime":"20160507200000888218","newstype":0,"updatetime":"20160507164313","coverimages":[]},{"dbid":0,"id":888255,"title":"乱用远光将被罚！福州启用远光抓拍系统","mediatype":0,"type":"用车养车","time":"2016-05-07","intacttime":"2016/5/7 0:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M07/55/93/400x300_0_autohomecar__wKgFV1csdfSADiKVAAEyVFFKyRE982.jpg","replycount":2781,"pagecount":1,"jumppage":1,"lasttime":"20160507000000888255","newstype":0,"updatetime":"20160506222954","coverimages":[]},{"dbid":0,"id":887065,"title":"出了事儿才发现不够赔？一张图聊三者险","mediatype":0,"type":"用车养车","time":"2016-05-04","intacttime":"2016/5/4 20:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M08/71/CE/400x300_0_autohomecar__wKgH5lcrDwGAYEdjAAGZTzpOuMY199.jpg","replycount":883,"pagecount":1,"jumppage":1,"lasttime":"20160504200000887065","newstype":0,"updatetime":"20160505171445","coverimages":[]},{"dbid":0,"id":888067,"title":"私家车变身教练车？体验副刹车装置","mediatype":0,"type":"用车养车","time":"2016-05-04","intacttime":"2016/5/4 0:35:21","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g17/M09/69/63/400x300_0_autohomecar__wKjBxlcoczaAGsIWAAGkXwbT-ls491.jpg","replycount":590,"pagecount":2,"jumppage":1,"lasttime":"20160504003521888067","newstype":0,"updatetime":"20160504004043","coverimages":[]},{"dbid":0,"id":888128,"title":"您怎么看？有偿举报交通违法你支持吗","mediatype":0,"type":"用车养车","time":"2016-05-03","intacttime":"2016/5/3 12:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g17/M03/68/96/400x300_0_autohomecar__wKjBxlcoCq2AS0T7AAGEWD419-I148.jpg","replycount":2179,"pagecount":1,"jumppage":1,"lasttime":"20160503120000888128","newstype":0,"updatetime":"20160503141456","coverimages":[]},{"dbid":0,"id":887754,"title":"您怎么看 会考虑原车儿童座椅套装吗？","mediatype":0,"type":"用车养车","time":"2016-04-30","intacttime":"2016/4/30 20:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M03/69/93/400x300_0_autohomecar__wKgH0lcjBWOAKS54AAGdESfSDoQ577.jpg","replycount":78,"pagecount":1,"jumppage":1,"lasttime":"20160430200000887754","newstype":0,"updatetime":"20160501092142","coverimages":[]},{"dbid":0,"id":888000,"title":"黑科技真的好用吗？谈汽车多媒体的应用","mediatype":0,"type":"用车养车","time":"2016-04-30","intacttime":"2016/4/30 0:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g15/M0C/68/F6/400x300_0_autohomecar__wKgH1lchhrSAYKr5AAHaaI87GaA153.jpg","replycount":128,"pagecount":1,"jumppage":1,"lasttime":"20160430000000888000","newstype":0,"updatetime":"20160430193735","coverimages":[]},{"dbid":0,"id":887912,"title":"保养间隔最长2万公里 图雅诺养车成本","mediatype":0,"type":"用车养车","time":"2016-04-29","intacttime":"2016/4/29 20:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M08/4A/71/400x300_0_autohomecar__wKjBw1ciF3aAeUm0AAHJHD-cXRA716.jpg","replycount":65,"pagecount":2,"jumppage":1,"lasttime":"20160429200000887912","newstype":0,"updatetime":"20160429140501","coverimages":[]},{"dbid":0,"id":887459,"title":"您怎么看？因为盲区而撞上儿童到底怪谁","mediatype":0,"type":"用车养车","time":"2016-04-28","intacttime":"2016/4/28 20:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g16/M05/68/63/400x300_0_autohomecar__wKgH5lchxEiAE3lhAAF4bjJq95k658.jpg","replycount":555,"pagecount":1,"jumppage":1,"lasttime":"20160428200000887459","newstype":0,"updatetime":"20160428174124","coverimages":[]},{"dbid":0,"id":887982,"title":"暴戾之气！宾利女司机招人殴打保安","mediatype":0,"type":"用车养车","time":"2016-04-28","intacttime":"2016/4/28 0:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g11/M04/66/90/400x300_0_autohomecar__wKjBzFcgtLyAagmSAAFDIXmDvWU616.jpg","replycount":3754,"pagecount":1,"jumppage":1,"lasttime":"20160428000000887982","newstype":0,"updatetime":"20160503172000","coverimages":[]},{"dbid":0,"id":887979,"title":"到底哪儿最堵？高德发布五·一出行预测","mediatype":0,"type":"用车养车","time":"2016-04-28","intacttime":"2016/4/28 0:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M03/49/E8/400x300_0_autohomecar__wKgFVlcgn5aATgZKAAIZ7vji-E0693.jpg","replycount":187,"pagecount":1,"jumppage":1,"lasttime":"20160428000000887979","newstype":0,"updatetime":"20160427222958","coverimages":[]},{"dbid":0,"id":887460,"title":"您怎么看？孩子不喜欢坐儿童座椅怎么办","mediatype":0,"type":"用车养车","time":"2016-04-27","intacttime":"2016/4/27 20:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M0C/65/E9/400x300_0_autohomecar__wKgH1VcgiBSAewdJAAGMMZVcoIE734.jpg","replycount":416,"pagecount":1,"jumppage":1,"lasttime":"20160427200000887460","newstype":0,"updatetime":"20160427175610","coverimages":[]}]
     * topnewsinfo : {}
     */

    private ResultBean result;
    /**
     * result : {"rowcount":1569,"isloadmore":true,"headlineinfo":{},"focusimg":[],"newslist":[{"dbid":0,"id":888410,"title":"手机定损？谈App对移动定损带来的变革","mediatype":0,"type":"用车养车","time":"2016-05-12","intacttime":"2016/5/12 20:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g22/M08/5C/D6/400x300_0_autohomecar__wKgFVlc0LX-AS22QAAFvDrXjku8664.jpg","replycount":53,"pagecount":1,"jumppage":1,"lasttime":"20160512200000888410","newstype":0,"updatetime":"20160513145714","coverimages":[]},{"dbid":0,"id":888427,"title":"只动口不动手！百度车辆语音控制新方案","mediatype":0,"type":"用车养车","time":"2016-05-12","intacttime":"2016/5/12 1:34:14","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g7/M03/79/61/400x300_0_autohomecar__wKgHzlczZTiAS3pjAAEhNKe72iM965.jpg","replycount":201,"pagecount":1,"jumppage":1,"lasttime":"20160512013414888427","newstype":0,"updatetime":"20160512091549","coverimages":[]},{"dbid":0,"id":888428,"title":"携手搜狗导航 友衷发布AutoIO超能仪表","mediatype":0,"type":"用车养车","time":"2016-05-12","intacttime":"2016/5/12 0:44:15","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g8/M0E/7D/36/400x300_0_autohomecar__wKgH3lcz9QuAPjjDAAGZ7W8Qcm4716.jpg","replycount":23,"pagecount":1,"jumppage":1,"lasttime":"20160512004415888428","newstype":0,"updatetime":"20160512111444","coverimages":[]},{"dbid":0,"id":888152,"title":"春天洗个\u201c毛\u201d 汽车水箱清洗大作战","mediatype":0,"type":"用车养车","time":"2016-05-12","intacttime":"2016/5/12 0:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g20/M12/59/22/400x300_0_autohomecar__wKgFWVcwZA-AJOajAAH8srI0l8A028.jpg","replycount":354,"pagecount":1,"jumppage":1,"lasttime":"20160512000000888152","newstype":0,"updatetime":"20160512093019","coverimages":[]},{"dbid":0,"id":888417,"title":"四维图新在沪展示高精度地图和趣驾系统","mediatype":0,"type":"用车养车","time":"2016-05-11","intacttime":"2016/5/11 20:57:37","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g13/M08/7A/38/400x300_0_autohomecar__wKjBylcz6SWAMUjaAAFd6xsNv7s352.jpg","replycount":15,"pagecount":1,"jumppage":1,"lasttime":"20160511205737888417","newstype":0,"updatetime":"20160512102825","coverimages":[]},{"dbid":0,"id":888251,"title":"功能基本齐全 体验昕动多媒体和记录仪","mediatype":0,"type":"用车养车","time":"2016-05-10","intacttime":"2016/5/10 0:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g18/M0E/75/FE/400x300_0_autohomecar__wKjBxVcwWjWAXNP1AAF7US_BvS4391.jpg","replycount":94,"pagecount":3,"jumppage":1,"lasttime":"20160510000000888251","newstype":0,"updatetime":"20160510000200","coverimages":[]},{"dbid":0,"id":888335,"title":"您怎么看？草原天路变收费公路合理吗","mediatype":0,"type":"用车养车","time":"2016-05-09","intacttime":"2016/5/9 20:30:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M02/77/74/400x300_0_autohomecar__wKgH5FcwRN-ALvUTAAGnVwEfP_E812.jpg","replycount":1354,"pagecount":1,"jumppage":1,"lasttime":"20160509203000888335","newstype":0,"updatetime":"20160510073439","coverimages":[]},{"dbid":0,"id":888310,"title":"湿地驾驶更安全 玛吉斯发布全新HP5轮胎","mediatype":10,"type":"用车养车","time":"2016-05-08","intacttime":"2016/5/8 23:02:02","indexdetail":"http://www2.autoimg.cn/newsdfs/g20/M04/58/12/400x300_0_autohomecar__wKgFWVcvTquASkroAAC2I_m8cHM012.jpg㊣http://www2.autoimg.cn/newsdfs/g15/M03/76/FA/400x300_0_autohomecar__wKjByFcvVdyAd8ydAACNcUQ54to926.jpg㊣http://www2.autoimg.cn/newsdfs/g8/M01/78/99/400x300_0_autohomecar__wKgHz1cvTyKAcgOdAACkvAq5L4s583.jpg","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M0A/57/5F/400x300_0_autohomecar__wKjBw1cvTqmAUXT3AAFnI1UIjdY660.jpg","replycount":145,"pagecount":1,"jumppage":1,"lasttime":"20160508230202888310","newstype":0,"updatetime":"20160508235610","coverimages":[]},{"dbid":0,"id":888218,"title":"空调异味怎么办？编辑体验三种除味方法","mediatype":0,"type":"用车养车","time":"2016-05-07","intacttime":"2016/5/7 20:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g14/M13/70/51/400x300_0_autohomecar__wKjByVcq3aqAct5WAAGYzRuEMeM561.jpg","replycount":424,"pagecount":2,"jumppage":1,"lasttime":"20160507200000888218","newstype":0,"updatetime":"20160507164313","coverimages":[]},{"dbid":0,"id":888255,"title":"乱用远光将被罚！福州启用远光抓拍系统","mediatype":0,"type":"用车养车","time":"2016-05-07","intacttime":"2016/5/7 0:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M07/55/93/400x300_0_autohomecar__wKgFV1csdfSADiKVAAEyVFFKyRE982.jpg","replycount":2781,"pagecount":1,"jumppage":1,"lasttime":"20160507000000888255","newstype":0,"updatetime":"20160506222954","coverimages":[]},{"dbid":0,"id":887065,"title":"出了事儿才发现不够赔？一张图聊三者险","mediatype":0,"type":"用车养车","time":"2016-05-04","intacttime":"2016/5/4 20:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M08/71/CE/400x300_0_autohomecar__wKgH5lcrDwGAYEdjAAGZTzpOuMY199.jpg","replycount":883,"pagecount":1,"jumppage":1,"lasttime":"20160504200000887065","newstype":0,"updatetime":"20160505171445","coverimages":[]},{"dbid":0,"id":888067,"title":"私家车变身教练车？体验副刹车装置","mediatype":0,"type":"用车养车","time":"2016-05-04","intacttime":"2016/5/4 0:35:21","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g17/M09/69/63/400x300_0_autohomecar__wKjBxlcoczaAGsIWAAGkXwbT-ls491.jpg","replycount":590,"pagecount":2,"jumppage":1,"lasttime":"20160504003521888067","newstype":0,"updatetime":"20160504004043","coverimages":[]},{"dbid":0,"id":888128,"title":"您怎么看？有偿举报交通违法你支持吗","mediatype":0,"type":"用车养车","time":"2016-05-03","intacttime":"2016/5/3 12:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g17/M03/68/96/400x300_0_autohomecar__wKjBxlcoCq2AS0T7AAGEWD419-I148.jpg","replycount":2179,"pagecount":1,"jumppage":1,"lasttime":"20160503120000888128","newstype":0,"updatetime":"20160503141456","coverimages":[]},{"dbid":0,"id":887754,"title":"您怎么看 会考虑原车儿童座椅套装吗？","mediatype":0,"type":"用车养车","time":"2016-04-30","intacttime":"2016/4/30 20:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M03/69/93/400x300_0_autohomecar__wKgH0lcjBWOAKS54AAGdESfSDoQ577.jpg","replycount":78,"pagecount":1,"jumppage":1,"lasttime":"20160430200000887754","newstype":0,"updatetime":"20160501092142","coverimages":[]},{"dbid":0,"id":888000,"title":"黑科技真的好用吗？谈汽车多媒体的应用","mediatype":0,"type":"用车养车","time":"2016-04-30","intacttime":"2016/4/30 0:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g15/M0C/68/F6/400x300_0_autohomecar__wKgH1lchhrSAYKr5AAHaaI87GaA153.jpg","replycount":128,"pagecount":1,"jumppage":1,"lasttime":"20160430000000888000","newstype":0,"updatetime":"20160430193735","coverimages":[]},{"dbid":0,"id":887912,"title":"保养间隔最长2万公里 图雅诺养车成本","mediatype":0,"type":"用车养车","time":"2016-04-29","intacttime":"2016/4/29 20:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M08/4A/71/400x300_0_autohomecar__wKjBw1ciF3aAeUm0AAHJHD-cXRA716.jpg","replycount":65,"pagecount":2,"jumppage":1,"lasttime":"20160429200000887912","newstype":0,"updatetime":"20160429140501","coverimages":[]},{"dbid":0,"id":887459,"title":"您怎么看？因为盲区而撞上儿童到底怪谁","mediatype":0,"type":"用车养车","time":"2016-04-28","intacttime":"2016/4/28 20:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g16/M05/68/63/400x300_0_autohomecar__wKgH5lchxEiAE3lhAAF4bjJq95k658.jpg","replycount":555,"pagecount":1,"jumppage":1,"lasttime":"20160428200000887459","newstype":0,"updatetime":"20160428174124","coverimages":[]},{"dbid":0,"id":887982,"title":"暴戾之气！宾利女司机招人殴打保安","mediatype":0,"type":"用车养车","time":"2016-04-28","intacttime":"2016/4/28 0:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g11/M04/66/90/400x300_0_autohomecar__wKjBzFcgtLyAagmSAAFDIXmDvWU616.jpg","replycount":3754,"pagecount":1,"jumppage":1,"lasttime":"20160428000000887982","newstype":0,"updatetime":"20160503172000","coverimages":[]},{"dbid":0,"id":887979,"title":"到底哪儿最堵？高德发布五·一出行预测","mediatype":0,"type":"用车养车","time":"2016-04-28","intacttime":"2016/4/28 0:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M03/49/E8/400x300_0_autohomecar__wKgFVlcgn5aATgZKAAIZ7vji-E0693.jpg","replycount":187,"pagecount":1,"jumppage":1,"lasttime":"20160428000000887979","newstype":0,"updatetime":"20160427222958","coverimages":[]},{"dbid":0,"id":887460,"title":"您怎么看？孩子不喜欢坐儿童座椅怎么办","mediatype":0,"type":"用车养车","time":"2016-04-27","intacttime":"2016/4/27 20:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M0C/65/E9/400x300_0_autohomecar__wKgH1VcgiBSAewdJAAGMMZVcoIE734.jpg","replycount":416,"pagecount":1,"jumppage":1,"lasttime":"20160427200000887460","newstype":0,"updatetime":"20160427175610","coverimages":[]}],"topnewsinfo":{}}
     * returncode : 0
     * message :
     */

    private int returncode;
    private String message;

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class ResultBean {
        private int rowcount;
        private boolean isloadmore;
        private List<?> focusimg;
        /**
         * dbid : 0
         * id : 888410
         * title : 手机定损？谈App对移动定损带来的变革
         * mediatype : 0
         * type : 用车养车
         * time : 2016-05-12
         * intacttime : 2016/5/12 20:00:00
         * indexdetail :
         * smallpic : http://www2.autoimg.cn/newsdfs/g22/M08/5C/D6/400x300_0_autohomecar__wKgFVlc0LX-AS22QAAFvDrXjku8664.jpg
         * replycount : 53
         * pagecount : 1
         * jumppage : 1
         * lasttime : 20160512200000888410
         * newstype : 0
         * updatetime : 20160513145714
         * coverimages : []
         */

        private List<NewslistBean> newslist;

        public int getRowcount() {
            return rowcount;
        }

        public void setRowcount(int rowcount) {
            this.rowcount = rowcount;
        }

        public boolean isIsloadmore() {
            return isloadmore;
        }

        public void setIsloadmore(boolean isloadmore) {
            this.isloadmore = isloadmore;
        }

        public List<?> getFocusimg() {
            return focusimg;
        }

        public void setFocusimg(List<?> focusimg) {
            this.focusimg = focusimg;
        }

        public List<NewslistBean> getNewslist() {
            return newslist;
        }

        public void setNewslist(List<NewslistBean> newslist) {
            this.newslist = newslist;
        }

        public static class NewslistBean {
            private int dbid;
            private int id;
            private String title;
            private int mediatype;
            private String type;
            private String time;
            private String intacttime;
            private String indexdetail;
            private String smallpic;
            private int replycount;
            private int pagecount;
            private int jumppage;
            private String lasttime;
            private int newstype;
            private String updatetime;
            private List<?> coverimages;

            public int getDbid() {
                return dbid;
            }

            public void setDbid(int dbid) {
                this.dbid = dbid;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public int getMediatype() {
                return mediatype;
            }

            public void setMediatype(int mediatype) {
                this.mediatype = mediatype;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getIntacttime() {
                return intacttime;
            }

            public void setIntacttime(String intacttime) {
                this.intacttime = intacttime;
            }

            public String getIndexdetail() {
                return indexdetail;
            }

            public void setIndexdetail(String indexdetail) {
                this.indexdetail = indexdetail;
            }

            public String getSmallpic() {
                return smallpic;
            }

            public void setSmallpic(String smallpic) {
                this.smallpic = smallpic;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }

            public int getPagecount() {
                return pagecount;
            }

            public void setPagecount(int pagecount) {
                this.pagecount = pagecount;
            }

            public int getJumppage() {
                return jumppage;
            }

            public void setJumppage(int jumppage) {
                this.jumppage = jumppage;
            }

            public String getLasttime() {
                return lasttime;
            }

            public void setLasttime(String lasttime) {
                this.lasttime = lasttime;
            }

            public int getNewstype() {
                return newstype;
            }

            public void setNewstype(int newstype) {
                this.newstype = newstype;
            }

            public String getUpdatetime() {
                return updatetime;
            }

            public void setUpdatetime(String updatetime) {
                this.updatetime = updatetime;
            }

            public List<?> getCoverimages() {
                return coverimages;
            }

            public void setCoverimages(List<?> coverimages) {
                this.coverimages = coverimages;
            }
        }
    }
}
