package com.lanou3g.autohome.recommendbean;

import java.util.List;

/**
 * Created by dllo on 16/5/12.
 */
public class VideoBean {

    /**
     * isloadmore : true
     * rowcount : 67021
     * pagecount : 3192
     * pageindex : 0
     * list : [{"id":80481,"title":"《萝卜实验室》 磁性手机支架介绍/使用","type":"花边","time":"2016-05-12","indexdetail":"萝卜报告原创视频","smallimg":"http://www3.autoimg.cn/newsdfs/g9/M14/74/35/120x90_0_autohomecar__wKjBzlc0F--ATFz_AAFACgDGVL0151.jpg","replycount":11,"playcount":547,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80481.html","updatetime":"20160512134312","lastid":"201605121343132016051213432680481"},{"id":80422,"title":"Ghibli Diesel 3.0T 秀诱人排气声浪","type":"花边","time":"2016-05-12","indexdetail":"视频展示了玛莎拉蒂Ghibli Diesel 3.0T V6的排气声浪","smallimg":"http://www3.autoimg.cn/newsdfs/g18/M01/79/12/120x90_0_autohomecar__wKjBxVcz2XeABp70AAGZvCkD2pY610.jpg","replycount":7,"playcount":720,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80422.html","updatetime":"20160512091648","lastid":"201605120916482016051213115180422"},{"id":80427,"title":"真想骂街 摄像车躲避左转车冲上隔离带","type":"花边","time":"2016-05-12","indexdetail":"摄像车直行，为了躲避左转的绿色小车冲上隔离带，左转车居然直接开走了。","smallimg":"http://www3.autoimg.cn/newsdfs/g10/M12/79/F8/120x90_0_autohomecar__wKjBzVcz326AM4ckAAEtCV2tlLA065.jpg","replycount":9,"playcount":672,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80427.html","updatetime":"20160512094810","lastid":"201605120948112016051213114780427"},{"id":80461,"title":"泥水四溅 暴改大脚福特皮卡泥水滩狂飙","type":"花边","time":"2016-05-12","indexdetail":"暴改大脚福特皮卡泥水滩狂飙","smallimg":"http://www2.autoimg.cn/newsdfs/g10/M0B/7A/0B/120x90_0_autohomecar__wKjBzVcz6LCAYKOhAAFgaboRgeQ309.jpg","replycount":2,"playcount":1174,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80461.html","updatetime":"20160512102137","lastid":"201605121021372016051213114080461"},{"id":80441,"title":"要命的节奏 看小轿车未减速直接追尾","type":"花边","time":"2016-05-12","indexdetail":"视频展示了小车高速行车刹车不及，追尾前方停着的厢式货车。","smallimg":"http://www2.autoimg.cn/newsdfs/g12/M0E/78/58/120x90_0_autohomecar__wKgH01cz49iALwk2AAETxzMPiaQ089.jpg","replycount":4,"playcount":1096,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80441.html","updatetime":"20160512100058","lastid":"201605121000592016051213113680441"},{"id":80424,"title":"全场的焦点 Huracan LP 580-2赛道暴走","type":"花边","time":"2016-05-12","indexdetail":"视频展示了兰博基尼Huracan LP 580-2跑赛道的精彩镜头","smallimg":"http://www3.autoimg.cn/newsdfs/g18/M13/79/9B/120x90_0_autohomecar__wKgH6Fcz3D2AIVFfAADq5-U3VBs445.jpg","replycount":1,"playcount":638,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80424.html","updatetime":"20160512093026","lastid":"201605120930262016051213112780424"},{"id":80431,"title":"加速实测 2016款特斯拉MODEL S 90D","type":"花边","time":"2016-05-12","indexdetail":"2016款特斯拉MODEL S 90D秀加速","smallimg":"http://www3.autoimg.cn/newsdfs/g11/M0D/7A/01/120x90_0_autohomecar__wKgH4Vcz4WmASnOyAAGg8ThgnRM098.jpg","replycount":3,"playcount":828,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80431.html","updatetime":"20160512095034","lastid":"201605120950352016051213102580431"},{"id":80435,"title":"难以掩饰的凶狠 街拍暴力改装日产370Z","type":"花边","time":"2016-05-12","indexdetail":"视频展示了一辆非常吸睛的改装日产370Z","smallimg":"http://www3.autoimg.cn/newsdfs/g14/M05/79/24/120x90_0_autohomecar__wKgH1Vcz4mCAe7MtAAFz_LU8-lo011.jpg","replycount":2,"playcount":1323,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80435.html","updatetime":"20160512095446","lastid":"201605120954462016051213101680435"},{"id":80437,"title":"主视角体验 2016款奥迪S7黑夜雪地驾驶","type":"花边","time":"2016-05-12","indexdetail":"体验2016款奥迪S7黑夜雪地驾驶","smallimg":"http://www2.autoimg.cn/newsdfs/g6/M13/79/80/120x90_0_autohomecar__wKjB0Vcz4z2AWx_IAACy-0NqP28518.jpg","replycount":1,"playcount":606,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80437.html","updatetime":"20160512095827","lastid":"201605120958282016051213101180437"},{"id":80421,"title":"赛道王者 Granturismo MC GT4秀性能","type":"花边","time":"2016-05-12","indexdetail":"视频展示了玛莎拉蒂Granturismo MC GT4在赛道秀加速性能","smallimg":"http://www2.autoimg.cn/newsdfs/g14/M0B/7A/BB/120x90_0_autohomecar__wKgH5Fcz2LmAB5ejAAEudOOmLyw441.jpg","replycount":1,"playcount":215,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80421.html","updatetime":"20160512091406","lastid":"201605120914072016051213100280421"},{"id":80451,"title":"就这么任性 看低趴范儿皮卡车的聚会","type":"花边","time":"2016-05-12","indexdetail":"视频展示了多辆暴改低趴范儿的皮卡车大聚会","smallimg":"http://www3.autoimg.cn/newsdfs/g11/M0B/7A/05/120x90_0_autohomecar__wKgH4Vcz5aqAZpZfAAEtZj4AdZ0099.jpg","replycount":1,"playcount":391,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80451.html","updatetime":"20160512100844","lastid":"201605121008452016051213091980451"},{"id":80420,"title":"《力所应当》第4集 遭遇熊抱突袭怎么办","type":"原创","time":"2016-05-11","indexdetail":"《力所应当》是由汽车之家和来自美国FORCE NECESSARY 战术格斗教官刘上共同打造的车用防身术情景剧，第四集《请君入瓮》主要为大家讲解被人从背后熊抱如何化解。","smallimg":"http://www2.autoimg.cn/newsdfs/g17/M09/74/4C/120x90_0_autohomecar__wKjBxlczVWCAZxtpAAEP1tkNdzg622.jpg","replycount":155,"playcount":48094,"nickname":"张文君","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_8_80420.html","updatetime":"20160511235309","lastid":"201605111924492016051208592080420"},{"id":80401,"title":"顶级豪华之争 对比宾利添越/揽胜特别版","type":"试车","time":"2016-05-12","indexdetail":"视频中带来了一组顶级豪华SUV之争，添越/揽胜特别版，这两辆你更喜欢谁呢？","smallimg":"http://www3.autoimg.cn/newsdfs/g7/M0D/78/9C/120x90_0_autohomecar__wKgHzlcyyl6AFoxtAAGfvrhu6FY576.jpg","replycount":404,"playcount":84522,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_2_80401.html","updatetime":"20160512000233","lastid":"201605120002332016051208541580401"},{"id":80398,"title":"犹如小型车展 街拍日本各类低趴改装车","type":"花边","time":"2016-05-11","indexdetail":"视频展示了日本众多低趴改装车的聚会.对于车友来说改装车过坎、过坡确实是一件很头疼的事情。","smallimg":"http://www2.autoimg.cn/newsdfs/g22/M01/5B/44/120x90_0_autohomecar__wKjBwVcy8maASfRaAAFTs7vNcvM790.jpg","replycount":73,"playcount":24919,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80398.html","updatetime":"20160511165320","lastid":"201605111653202016051208300080398"},{"id":80376,"title":"真心不错！土豪美女体验新款福特野马","type":"花边","time":"2016-05-11","indexdetail":"土豪美女体验新款福特野马","smallimg":"http://www3.autoimg.cn/newsdfs/g15/M0F/77/0B/120x90_0_autohomecar__wKgH5Vcy8kGAE1d5AAEv_YClR0Q953.jpg","replycount":19,"playcount":12534,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80376.html","updatetime":"20160511165010","lastid":"201605111650112016051208300080376"},{"id":80411,"title":"2015款奥迪S8 plus 0-300km/h加速测试","type":"花边","time":"2016-05-11","indexdetail":"视频展示了2015款奥迪S8 plus 0-300km/h加速测试","smallimg":"http://www3.autoimg.cn/newsdfs/g15/M02/7A/4B/120x90_0_autohomecar__wKjByFcy1ZqAMzxNAAE4ESl03eU382.jpg","replycount":64,"playcount":16631,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80411.html","updatetime":"20160511144755","lastid":"201605111447552016051208300080411"},{"id":80406,"title":"主视角体验 宝马i8狭窄赛道极速狂飙","type":"花边","time":"2016-05-11","indexdetail":"视频展示了主视角看宝马i8在狭窄赛道中极速狂飙","smallimg":"http://www2.autoimg.cn/newsdfs/g13/M0A/79/4E/120x90_0_autohomecar__wKjBylcyz-uAGdLiAAEnALuJk1Y143.jpg","replycount":16,"playcount":12501,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80406.html","updatetime":"20160511144446","lastid":"201605111444462016051208300080406"},{"id":80409,"title":"声浪响彻山谷 方程式赛车山路精彩飙车","type":"花边","time":"2016-05-11","indexdetail":"视频展示了方程式赛车在山路过弯时的精彩飙车镜头","smallimg":"http://www2.autoimg.cn/newsdfs/g7/M0B/78/A9/120x90_0_autohomecar__wKgHzlcy08aAOudeAAFpdDoRgZw125.jpg","replycount":30,"playcount":16833,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80409.html","updatetime":"20160511144008","lastid":"201605111440082016051208300080409"},{"id":80407,"title":"车内藏猎枪 冲突中掏枪就往人群中乱射","type":"事件","time":"2016-05-11","indexdetail":"视频展示了冲突者打架用车内取出的猎枪乱射的恐怖过程","smallimg":"http://www2.autoimg.cn/newsdfs/g15/M0A/7A/47/120x90_0_autohomecar__wKjByFcy0X6Ab-O_AAExttYU7CM267.jpg","replycount":73,"playcount":97017,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_7_80407.html","updatetime":"20160511143025","lastid":"201605111430252016051208300080407"},{"id":80405,"title":"1000cc的发动机 牛人打造大排量钢管车","type":"花边","time":"2016-05-11","indexdetail":"视频展示了国外牛人打造搭载本田CBR1000F的1000cc摩托车发动机的钢管车","smallimg":"http://www2.autoimg.cn/newsdfs/g19/M15/5A/F8/120x90_0_autohomecar__wKjBxFcyzreAX2CbAAFAc9gfmok948.jpg","replycount":11,"playcount":11677,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80405.html","updatetime":"20160511141834","lastid":"201605111418332016051208300080405"}]
     */

    private ResultBean result;
    /**
     * result : {"isloadmore":true,"rowcount":67021,"pagecount":3192,"pageindex":0,"list":[{"id":80481,"title":"《萝卜实验室》 磁性手机支架介绍/使用","type":"花边","time":"2016-05-12","indexdetail":"萝卜报告原创视频","smallimg":"http://www3.autoimg.cn/newsdfs/g9/M14/74/35/120x90_0_autohomecar__wKjBzlc0F--ATFz_AAFACgDGVL0151.jpg","replycount":11,"playcount":547,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80481.html","updatetime":"20160512134312","lastid":"201605121343132016051213432680481"},{"id":80422,"title":"Ghibli Diesel 3.0T 秀诱人排气声浪","type":"花边","time":"2016-05-12","indexdetail":"视频展示了玛莎拉蒂Ghibli Diesel 3.0T V6的排气声浪","smallimg":"http://www3.autoimg.cn/newsdfs/g18/M01/79/12/120x90_0_autohomecar__wKjBxVcz2XeABp70AAGZvCkD2pY610.jpg","replycount":7,"playcount":720,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80422.html","updatetime":"20160512091648","lastid":"201605120916482016051213115180422"},{"id":80427,"title":"真想骂街 摄像车躲避左转车冲上隔离带","type":"花边","time":"2016-05-12","indexdetail":"摄像车直行，为了躲避左转的绿色小车冲上隔离带，左转车居然直接开走了。","smallimg":"http://www3.autoimg.cn/newsdfs/g10/M12/79/F8/120x90_0_autohomecar__wKjBzVcz326AM4ckAAEtCV2tlLA065.jpg","replycount":9,"playcount":672,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80427.html","updatetime":"20160512094810","lastid":"201605120948112016051213114780427"},{"id":80461,"title":"泥水四溅 暴改大脚福特皮卡泥水滩狂飙","type":"花边","time":"2016-05-12","indexdetail":"暴改大脚福特皮卡泥水滩狂飙","smallimg":"http://www2.autoimg.cn/newsdfs/g10/M0B/7A/0B/120x90_0_autohomecar__wKjBzVcz6LCAYKOhAAFgaboRgeQ309.jpg","replycount":2,"playcount":1174,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80461.html","updatetime":"20160512102137","lastid":"201605121021372016051213114080461"},{"id":80441,"title":"要命的节奏 看小轿车未减速直接追尾","type":"花边","time":"2016-05-12","indexdetail":"视频展示了小车高速行车刹车不及，追尾前方停着的厢式货车。","smallimg":"http://www2.autoimg.cn/newsdfs/g12/M0E/78/58/120x90_0_autohomecar__wKgH01cz49iALwk2AAETxzMPiaQ089.jpg","replycount":4,"playcount":1096,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80441.html","updatetime":"20160512100058","lastid":"201605121000592016051213113680441"},{"id":80424,"title":"全场的焦点 Huracan LP 580-2赛道暴走","type":"花边","time":"2016-05-12","indexdetail":"视频展示了兰博基尼Huracan LP 580-2跑赛道的精彩镜头","smallimg":"http://www3.autoimg.cn/newsdfs/g18/M13/79/9B/120x90_0_autohomecar__wKgH6Fcz3D2AIVFfAADq5-U3VBs445.jpg","replycount":1,"playcount":638,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80424.html","updatetime":"20160512093026","lastid":"201605120930262016051213112780424"},{"id":80431,"title":"加速实测 2016款特斯拉MODEL S 90D","type":"花边","time":"2016-05-12","indexdetail":"2016款特斯拉MODEL S 90D秀加速","smallimg":"http://www3.autoimg.cn/newsdfs/g11/M0D/7A/01/120x90_0_autohomecar__wKgH4Vcz4WmASnOyAAGg8ThgnRM098.jpg","replycount":3,"playcount":828,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80431.html","updatetime":"20160512095034","lastid":"201605120950352016051213102580431"},{"id":80435,"title":"难以掩饰的凶狠 街拍暴力改装日产370Z","type":"花边","time":"2016-05-12","indexdetail":"视频展示了一辆非常吸睛的改装日产370Z","smallimg":"http://www3.autoimg.cn/newsdfs/g14/M05/79/24/120x90_0_autohomecar__wKgH1Vcz4mCAe7MtAAFz_LU8-lo011.jpg","replycount":2,"playcount":1323,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80435.html","updatetime":"20160512095446","lastid":"201605120954462016051213101680435"},{"id":80437,"title":"主视角体验 2016款奥迪S7黑夜雪地驾驶","type":"花边","time":"2016-05-12","indexdetail":"体验2016款奥迪S7黑夜雪地驾驶","smallimg":"http://www2.autoimg.cn/newsdfs/g6/M13/79/80/120x90_0_autohomecar__wKjB0Vcz4z2AWx_IAACy-0NqP28518.jpg","replycount":1,"playcount":606,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80437.html","updatetime":"20160512095827","lastid":"201605120958282016051213101180437"},{"id":80421,"title":"赛道王者 Granturismo MC GT4秀性能","type":"花边","time":"2016-05-12","indexdetail":"视频展示了玛莎拉蒂Granturismo MC GT4在赛道秀加速性能","smallimg":"http://www2.autoimg.cn/newsdfs/g14/M0B/7A/BB/120x90_0_autohomecar__wKgH5Fcz2LmAB5ejAAEudOOmLyw441.jpg","replycount":1,"playcount":215,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80421.html","updatetime":"20160512091406","lastid":"201605120914072016051213100280421"},{"id":80451,"title":"就这么任性 看低趴范儿皮卡车的聚会","type":"花边","time":"2016-05-12","indexdetail":"视频展示了多辆暴改低趴范儿的皮卡车大聚会","smallimg":"http://www3.autoimg.cn/newsdfs/g11/M0B/7A/05/120x90_0_autohomecar__wKgH4Vcz5aqAZpZfAAEtZj4AdZ0099.jpg","replycount":1,"playcount":391,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80451.html","updatetime":"20160512100844","lastid":"201605121008452016051213091980451"},{"id":80420,"title":"《力所应当》第4集 遭遇熊抱突袭怎么办","type":"原创","time":"2016-05-11","indexdetail":"《力所应当》是由汽车之家和来自美国FORCE NECESSARY 战术格斗教官刘上共同打造的车用防身术情景剧，第四集《请君入瓮》主要为大家讲解被人从背后熊抱如何化解。","smallimg":"http://www2.autoimg.cn/newsdfs/g17/M09/74/4C/120x90_0_autohomecar__wKjBxlczVWCAZxtpAAEP1tkNdzg622.jpg","replycount":155,"playcount":48094,"nickname":"张文君","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_8_80420.html","updatetime":"20160511235309","lastid":"201605111924492016051208592080420"},{"id":80401,"title":"顶级豪华之争 对比宾利添越/揽胜特别版","type":"试车","time":"2016-05-12","indexdetail":"视频中带来了一组顶级豪华SUV之争，添越/揽胜特别版，这两辆你更喜欢谁呢？","smallimg":"http://www3.autoimg.cn/newsdfs/g7/M0D/78/9C/120x90_0_autohomecar__wKgHzlcyyl6AFoxtAAGfvrhu6FY576.jpg","replycount":404,"playcount":84522,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_2_80401.html","updatetime":"20160512000233","lastid":"201605120002332016051208541580401"},{"id":80398,"title":"犹如小型车展 街拍日本各类低趴改装车","type":"花边","time":"2016-05-11","indexdetail":"视频展示了日本众多低趴改装车的聚会.对于车友来说改装车过坎、过坡确实是一件很头疼的事情。","smallimg":"http://www2.autoimg.cn/newsdfs/g22/M01/5B/44/120x90_0_autohomecar__wKjBwVcy8maASfRaAAFTs7vNcvM790.jpg","replycount":73,"playcount":24919,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80398.html","updatetime":"20160511165320","lastid":"201605111653202016051208300080398"},{"id":80376,"title":"真心不错！土豪美女体验新款福特野马","type":"花边","time":"2016-05-11","indexdetail":"土豪美女体验新款福特野马","smallimg":"http://www3.autoimg.cn/newsdfs/g15/M0F/77/0B/120x90_0_autohomecar__wKgH5Vcy8kGAE1d5AAEv_YClR0Q953.jpg","replycount":19,"playcount":12534,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80376.html","updatetime":"20160511165010","lastid":"201605111650112016051208300080376"},{"id":80411,"title":"2015款奥迪S8 plus 0-300km/h加速测试","type":"花边","time":"2016-05-11","indexdetail":"视频展示了2015款奥迪S8 plus 0-300km/h加速测试","smallimg":"http://www3.autoimg.cn/newsdfs/g15/M02/7A/4B/120x90_0_autohomecar__wKjByFcy1ZqAMzxNAAE4ESl03eU382.jpg","replycount":64,"playcount":16631,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80411.html","updatetime":"20160511144755","lastid":"201605111447552016051208300080411"},{"id":80406,"title":"主视角体验 宝马i8狭窄赛道极速狂飙","type":"花边","time":"2016-05-11","indexdetail":"视频展示了主视角看宝马i8在狭窄赛道中极速狂飙","smallimg":"http://www2.autoimg.cn/newsdfs/g13/M0A/79/4E/120x90_0_autohomecar__wKjBylcyz-uAGdLiAAEnALuJk1Y143.jpg","replycount":16,"playcount":12501,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80406.html","updatetime":"20160511144446","lastid":"201605111444462016051208300080406"},{"id":80409,"title":"声浪响彻山谷 方程式赛车山路精彩飙车","type":"花边","time":"2016-05-11","indexdetail":"视频展示了方程式赛车在山路过弯时的精彩飙车镜头","smallimg":"http://www2.autoimg.cn/newsdfs/g7/M0B/78/A9/120x90_0_autohomecar__wKgHzlcy08aAOudeAAFpdDoRgZw125.jpg","replycount":30,"playcount":16833,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80409.html","updatetime":"20160511144008","lastid":"201605111440082016051208300080409"},{"id":80407,"title":"车内藏猎枪 冲突中掏枪就往人群中乱射","type":"事件","time":"2016-05-11","indexdetail":"视频展示了冲突者打架用车内取出的猎枪乱射的恐怖过程","smallimg":"http://www2.autoimg.cn/newsdfs/g15/M0A/7A/47/120x90_0_autohomecar__wKjByFcy0X6Ab-O_AAExttYU7CM267.jpg","replycount":73,"playcount":97017,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_7_80407.html","updatetime":"20160511143025","lastid":"201605111430252016051208300080407"},{"id":80405,"title":"1000cc的发动机 牛人打造大排量钢管车","type":"花边","time":"2016-05-11","indexdetail":"视频展示了国外牛人打造搭载本田CBR1000F的1000cc摩托车发动机的钢管车","smallimg":"http://www2.autoimg.cn/newsdfs/g19/M15/5A/F8/120x90_0_autohomecar__wKjBxFcyzreAX2CbAAFAc9gfmok948.jpg","replycount":11,"playcount":11677,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80405.html","updatetime":"20160511141834","lastid":"201605111418332016051208300080405"}]}
     * returncode : 0
     * message :
     */

    private int returncode;
    private String message;

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class ResultBean {
        private boolean isloadmore;
        private int rowcount;
        private int pagecount;
        private int pageindex;
        /**
         * id : 80481
         * title : 《萝卜实验室》 磁性手机支架介绍/使用
         * type : 花边
         * time : 2016-05-12
         * indexdetail : 萝卜报告原创视频
         * smallimg : http://www3.autoimg.cn/newsdfs/g9/M14/74/35/120x90_0_autohomecar__wKjBzlc0F--ATFz_AAFACgDGVL0151.jpg
         * replycount : 11
         * playcount : 547
         * nickname : 陆维
         * videoaddress : http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8
         * shareaddress : http://v.autohome.com.cn/v_4_80481.html
         * updatetime : 20160512134312
         * lastid : 201605121343132016051213432680481
         */

        private List<ListBean> list;

        public boolean isIsloadmore() {
            return isloadmore;
        }

        public void setIsloadmore(boolean isloadmore) {
            this.isloadmore = isloadmore;
        }

        public int getRowcount() {
            return rowcount;
        }

        public void setRowcount(int rowcount) {
            this.rowcount = rowcount;
        }

        public int getPagecount() {
            return pagecount;
        }

        public void setPagecount(int pagecount) {
            this.pagecount = pagecount;
        }

        public int getPageindex() {
            return pageindex;
        }

        public void setPageindex(int pageindex) {
            this.pageindex = pageindex;
        }

        public List<ListBean> getList() {
            return list;
        }

        public void setList(List<ListBean> list) {
            this.list = list;
        }

        public static class ListBean {
            private int id;
            private String title;
            private String type;
            private String time;
            private String indexdetail;
            private String smallimg;
            private int replycount;
            private int playcount;
            private String nickname;
            private String videoaddress;
            private String shareaddress;
            private String updatetime;
            private String lastid;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getIndexdetail() {
                return indexdetail;
            }

            public void setIndexdetail(String indexdetail) {
                this.indexdetail = indexdetail;
            }

            public String getSmallimg() {
                return smallimg;
            }

            public void setSmallimg(String smallimg) {
                this.smallimg = smallimg;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }

            public int getPlaycount() {
                return playcount;
            }

            public void setPlaycount(int playcount) {
                this.playcount = playcount;
            }

            public String getNickname() {
                return nickname;
            }

            public void setNickname(String nickname) {
                this.nickname = nickname;
            }

            public String getVideoaddress() {
                return videoaddress;
            }

            public void setVideoaddress(String videoaddress) {
                this.videoaddress = videoaddress;
            }

            public String getShareaddress() {
                return shareaddress;
            }

            public void setShareaddress(String shareaddress) {
                this.shareaddress = shareaddress;
            }

            public String getUpdatetime() {
                return updatetime;
            }

            public void setUpdatetime(String updatetime) {
                this.updatetime = updatetime;
            }

            public String getLastid() {
                return lastid;
            }

            public void setLastid(String lastid) {
                this.lastid = lastid;
            }
        }
    }
}
