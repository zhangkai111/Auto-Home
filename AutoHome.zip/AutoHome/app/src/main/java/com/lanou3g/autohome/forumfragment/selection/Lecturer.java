package com.lanou3g.autohome.forumfragment.selection;

import android.view.View;

import com.lanou3g.autohome.R;
import com.lanou3g.autohome.base.BaseFragment;

/**
 * Created by dllo on 16/5/9.
 * 论坛讲师
 */
public class Lecturer extends BaseFragment {
    @Override
    public int initLayout() {
        return R.layout.selection_lecturer;
    }

    @Override
    public void initView() {

    }

    @Override
    public void initData() {

    }
}
