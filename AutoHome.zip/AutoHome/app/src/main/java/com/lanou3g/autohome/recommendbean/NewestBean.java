package com.lanou3g.autohome.recommendbean;

import java.util.List;

/**
 * Created by dllo on 16/5/10.
 */
public class NewestBean {

    /**
     * rowcount : 10200
     * pagecount : 340
     * pageindex : 1
     * headlineinfo : {"id":888319,"title":"11城市政策详解 2016年电动车购买宝典","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M0F/59/01/160x120_0_autohomecar__wKgFVFcwbU6AZyBnAAF8u6RV25c120.jpg","replycount":276,"pagecount":0,"jumppage":1,"lasttime":""}
     * focusimg : [{"id":888352,"imgurl":"http://www3.autoimg.cn/newsdfs/g4/M10/76/84/640x320_0_autohomecar__wKgHy1cxG4-ADptQAAcfr3bwjcY027.jpg","title":"年轻就要更运动 试驾东风日产新款骐达","type":"试驾评测","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":1},{"id":888338,"imgurl":"http://www3.autoimg.cn/newsdfs/g12/M0F/78/1D/640x320_0_autohomecar__wKjBy1cwntmAdxacAAfzMfCEVcY156.jpg","title":"脱胎换骨般的内饰 2016款瑞虎3到店实拍","type":"选车导购","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":1},{"id":887423,"imgurl":"http://www2.autoimg.cn/newsdfs/g15/M0F/74/9F/640x320_0_autohomecar__wKgH5Vcwb8eAU71pAAMi2lQ_k2w224.jpg","title":"凹凸姐漫谈第一集：发动机是如何启动的","type":"技术设计","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":1},{"id":51681197,"imgurl":"http://www3.autoimg.cn/newsdfs/g22/M0A/59/65/640x320_0_autohomecar__wKgFW1cwuiiAXLYwAAK3orwFXog619.jpg","title":"家中第五辆本田 全新思域论坛首发","type":"","replycount":0,"pageindex":9901135,"JumpType":0,"jumpurl":"","mediatype":4},{"id":52215536,"imgurl":"http://www2.autoimg.cn/newsdfs/g9/M0C/7A/70/640x320_0_autohomecar__wKgH31cws4yAMbCBAAJEuo1DHi0098.jpg","title":"品牌情怀终圆梦 提凯迪拉克XT5 28T","type":"","replycount":0,"pageindex":3989,"JumpType":0,"jumpurl":"","mediatype":4},{"id":888066,"imgurl":"http://www2.autoimg.cn/newsdfs/g15/M03/70/F3/640x320_0_autohomecar__wKgH5VcsnjyAZaOtAAe0-zoXsTw666.jpg","title":"终有一拼 君越28T静态对比皇冠2.0T","type":"选车导购","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":1}]
     * newslist : [{"id":80245,"title":"驾驶室遭猛撞 看小轿车路口左转酿事故","mediatype":3,"type":"花边","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M14/77/6A/240x180_0_autohomecar__wKgH4VcxPtSAGnXZAAFnIjuSN7E594.jpg","replycount":21470,"pagecount":0,"jumppage":1,"lasttime":""},{"id":517765,"title":"合资股比放开，中国品牌车企怕不怕？","mediatype":2,"type":"","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g17/M06/70/91/160x120_0_autohomecar__wKjBxlcv4geAPFsQAAE1j8M_xWo666.jpg","replycount":82,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80247,"title":"全程都很暴力 兰博基尼Huracan加速实录","mediatype":3,"type":"花边","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g20/M01/59/89/240x180_0_autohomecar__wKgFVFcxQMiATZcPAAFIir9fz3A821.jpg","replycount":17567,"pagecount":0,"jumppage":1,"lasttime":""},{"id":517271,"title":"\u201c恐怖\u201d的烧机油，你遇到过么？","mediatype":2,"type":"","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g4/M07/6F/9B/160x120_0_autohomecar__wKgH2lcpYxqAKPLnAACZ6et0sDI135.jpg","replycount":353,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80252,"title":"都是大力士 盘点那些尺寸巨大的发动机","mediatype":3,"type":"花边","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M01/5A/17/240x180_0_autohomecar__wKgFVFcxnCKACEtOAAFb8j_CtwQ589.jpg","replycount":41753,"pagecount":0,"jumppage":1,"lasttime":""},{"id":517756,"title":"平均只有33岁 开豪车的人竟月入9万？","mediatype":2,"type":"","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g6/M07/75/A6/160x120_0_autohomecar__wKjB0Vcv7tuAGG9aAAH18oGRR5A566.jpg","replycount":827,"pagecount":0,"jumppage":1,"lasttime":""},{"id":517846,"title":"这些年，C-NCAP\u201c撞\u201d过的十大安全车","mediatype":2,"type":"","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g18/M0D/76/88/160x120_0_autohomecar__wKgH6FcwZdSATP9cAADRl99aw7I165.jpg","replycount":329,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80240,"title":"公路惊险一幕！实拍小轿车雨天失控","mediatype":3,"type":"花边","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g18/M02/77/11/240x180_0_autohomecar__wKgH6FcxPVmARTy5AADyalonDr0782.jpg","replycount":32566,"pagecount":0,"jumppage":1,"lasttime":""},{"id":52273370,"title":"潮范轿跑SUV 马自达CX-4试驾直播","mediatype":5,"type":"c","time":"2016-05-10","indexdetail":"马自达CX-4论坛","smallpic":"http://club2.autoimg.cn/album/g16/M10/77/88/userphotos/2016/05/10/09/240180_wKgH5lcxPnmAR4qiAAEtMReAlOk988.jpg","replycount":780,"pagecount":0,"jumppage":3968,"lasttime":""},{"id":516783,"title":"实测：包场试车，赛道体验迈凯伦570S","mediatype":2,"type":"","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g5/M01/76/91/160x120_0_autohomecar__wKgHzFcwSzyAfB4pAAD2CdcNumU720.jpg","replycount":70,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80278,"title":"小型SUV市场中的新竞争者 16款绅宝X35","mediatype":3,"type":"到店实拍","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M04/77/57/240x180_0_autohomecar__wKgH11cxSZqAMBHKAAFVwX6hZHQ248.jpg","replycount":37830,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888347,"title":"或5月上市 奇瑞新款瑞虎3配置信息曝光","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g8/M08/7A/0F/160x120_0_autohomecar__wKgH3lcweU6AHboJAAF7JilQ_Ns892.jpg","replycount":384,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80244,"title":"赢的很轻松 看奥迪A6与傲虎的拔河对抗","mediatype":3,"type":"花边","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g4/M0C/77/5F/240x180_0_autohomecar__wKgH2lcxPpuAfin3AAEfem6MITs494.jpg","replycount":88723,"pagecount":0,"jumppage":1,"lasttime":""},{"id":517876,"title":"\u201c断轴\u201d速腾，会打个新\u201c补丁\u201d吗？","mediatype":2,"type":"","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g18/M06/76/81/160x120_0_autohomecar__wKgH6FcwYFyACxgXAAE_eq5E-48849.jpg","replycount":1185,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80236,"title":"绝对震撼 拉力赛车大雪山路强悍暴走","mediatype":3,"type":"花边","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g14/M11/78/2E/240x180_0_autohomecar__wKgH5FcxOgGAVoGAAADEnWaQN28958.jpg","replycount":39399,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888325,"title":"风阻系数为0.19 奔驰IAA概念车国内首发","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M13/5A/19/160x120_0_autohomecar__wKgFVlcxVOqAStVjAAFg6B4-gBo153.jpg","replycount":222,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888367,"title":"6月下旬亮相 野马新SUV T80预告图曝光","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M04/5A/41/160x120_0_autohomecar__wKgFXFcxUWyAU0kMAAER0hdc568359.jpg","replycount":750,"pagecount":0,"jumppage":1,"lasttime":""},{"id":514204,"title":"豪车和普通轿车的刹车有什么不同？","mediatype":2,"type":"","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g20/M03/2D/82/160x120_0_autohomecar__wKgFVFcEfL2AN4xAAAJ_wQq3tU4952.jpg","replycount":490,"pagecount":0,"jumppage":1,"lasttime":""},{"id":52062234,"title":"帅到没朋友 捷豹F-TYPE 3.0T提车","mediatype":5,"type":"c","time":"2016-05-10","indexdetail":"捷豹F-TYPE论坛","smallpic":"http://club2.autoimg.cn/album/g18/M15/6D/6A/userphotos/2016/05/03/12/240180_wKjBxVcoJLCAUIqFAAEnyk9wVic332.jpg","replycount":1874,"pagecount":0,"jumppage":2903,"lasttime":""},{"id":888366,"title":"或2018年发布 法拉利Dino假想图曝光","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g17/M0A/72/0A/160x120_0_autohomecar__wKjBxlcxTSqAVUWkAAEnKtJouUc408.jpg","replycount":194,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888364,"title":"2017年3月亮相 捷豹新款F-TYPE谍照曝光","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g21/M04/58/A5/160x120_0_autohomecar__wKjBwlcxR4qARfpwAAGraxqvlVI795.jpg","replycount":66,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888361,"title":"约300马力 下代牧马人将搭新2.0T发动机","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M11/76/8D/160x120_0_autohomecar__wKgH1VcxQA6AeqFvAAGn6utUaTQ403.jpg","replycount":443,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888359,"title":"2018年换代 新一代标致508信息曝光","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M0C/78/2F/160x120_0_autohomecar__wKgH5FcxOg2AGvENAAFBVAbjBqo249.jpg","replycount":400,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80200,"title":"太惊艳了 详拍科尔维特Z06 C7.R赛车版","mediatype":3,"type":"花边","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g9/M12/79/5F/240x180_0_autohomecar__wKgH31cwNBOANi02AAFx3hTQ2xY314.jpg","replycount":26823,"pagecount":0,"jumppage":1,"lasttime":""},{"id":517828,"title":"全国四月二手车交易分析","mediatype":2,"type":"","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g18/M01/76/3F/160x120_0_autohomecar__wKgH2VcwQsiAJQTwAAFsu97T8ZI057.jpg","replycount":129,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888362,"title":"曝兰博基尼Huracan Spyder LP580-2实车","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g17/M08/72/7E/160x120_0_autohomecar__wKgH2FcxPymAE3ZqAAFs_Ew4cC4923.jpg","replycount":98,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80230,"title":"最快柴油SUV 外媒试驾多面手奥迪SQ7","mediatype":3,"type":"试车","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g6/M07/76/2B/240x180_0_autohomecar__wKgHzVcwXtaAEqAeAAF0CZphb_g274.jpg","replycount":57790,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888356,"title":"年内发布 凯迪拉克新款CTS实车曝光","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M00/77/5D/160x120_0_autohomecar__wKjBzVcxME2AGw9ZAAGnrITAEuk195.jpg","replycount":481,"pagecount":0,"jumppage":1,"lasttime":""},{"id":517419,"title":"前驱X1还是我们熟悉的宝马吗?","mediatype":2,"type":"","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g5/M0E/70/B3/160x120_0_autohomecar__wKjB0lcquqaAEeqBAANHz0yZERY779.jpg","replycount":606,"pagecount":0,"jumppage":1,"lasttime":"201605100900004370817"}]
     * topnewsinfo : {}
     */

    private ResultBean result;
    /**
     * result : {"rowcount":10200,"pagecount":340,"pageindex":1,"headlineinfo":{"id":888319,"title":"11城市政策详解 2016年电动车购买宝典","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M0F/59/01/160x120_0_autohomecar__wKgFVFcwbU6AZyBnAAF8u6RV25c120.jpg","replycount":276,"pagecount":0,"jumppage":1,"lasttime":""},"focusimg":[{"id":888352,"imgurl":"http://www3.autoimg.cn/newsdfs/g4/M10/76/84/640x320_0_autohomecar__wKgHy1cxG4-ADptQAAcfr3bwjcY027.jpg","title":"年轻就要更运动 试驾东风日产新款骐达","type":"试驾评测","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":1},{"id":888338,"imgurl":"http://www3.autoimg.cn/newsdfs/g12/M0F/78/1D/640x320_0_autohomecar__wKjBy1cwntmAdxacAAfzMfCEVcY156.jpg","title":"脱胎换骨般的内饰 2016款瑞虎3到店实拍","type":"选车导购","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":1},{"id":887423,"imgurl":"http://www2.autoimg.cn/newsdfs/g15/M0F/74/9F/640x320_0_autohomecar__wKgH5Vcwb8eAU71pAAMi2lQ_k2w224.jpg","title":"凹凸姐漫谈第一集：发动机是如何启动的","type":"技术设计","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":1},{"id":51681197,"imgurl":"http://www3.autoimg.cn/newsdfs/g22/M0A/59/65/640x320_0_autohomecar__wKgFW1cwuiiAXLYwAAK3orwFXog619.jpg","title":"家中第五辆本田 全新思域论坛首发","type":"","replycount":0,"pageindex":9901135,"JumpType":0,"jumpurl":"","mediatype":4},{"id":52215536,"imgurl":"http://www2.autoimg.cn/newsdfs/g9/M0C/7A/70/640x320_0_autohomecar__wKgH31cws4yAMbCBAAJEuo1DHi0098.jpg","title":"品牌情怀终圆梦 提凯迪拉克XT5 28T","type":"","replycount":0,"pageindex":3989,"JumpType":0,"jumpurl":"","mediatype":4},{"id":888066,"imgurl":"http://www2.autoimg.cn/newsdfs/g15/M03/70/F3/640x320_0_autohomecar__wKgH5VcsnjyAZaOtAAe0-zoXsTw666.jpg","title":"终有一拼 君越28T静态对比皇冠2.0T","type":"选车导购","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":1}],"newslist":[{"id":80245,"title":"驾驶室遭猛撞 看小轿车路口左转酿事故","mediatype":3,"type":"花边","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M14/77/6A/240x180_0_autohomecar__wKgH4VcxPtSAGnXZAAFnIjuSN7E594.jpg","replycount":21470,"pagecount":0,"jumppage":1,"lasttime":""},{"id":517765,"title":"合资股比放开，中国品牌车企怕不怕？","mediatype":2,"type":"","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g17/M06/70/91/160x120_0_autohomecar__wKjBxlcv4geAPFsQAAE1j8M_xWo666.jpg","replycount":82,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80247,"title":"全程都很暴力 兰博基尼Huracan加速实录","mediatype":3,"type":"花边","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g20/M01/59/89/240x180_0_autohomecar__wKgFVFcxQMiATZcPAAFIir9fz3A821.jpg","replycount":17567,"pagecount":0,"jumppage":1,"lasttime":""},{"id":517271,"title":"\u201c恐怖\u201d的烧机油，你遇到过么？","mediatype":2,"type":"","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g4/M07/6F/9B/160x120_0_autohomecar__wKgH2lcpYxqAKPLnAACZ6et0sDI135.jpg","replycount":353,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80252,"title":"都是大力士 盘点那些尺寸巨大的发动机","mediatype":3,"type":"花边","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M01/5A/17/240x180_0_autohomecar__wKgFVFcxnCKACEtOAAFb8j_CtwQ589.jpg","replycount":41753,"pagecount":0,"jumppage":1,"lasttime":""},{"id":517756,"title":"平均只有33岁 开豪车的人竟月入9万？","mediatype":2,"type":"","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g6/M07/75/A6/160x120_0_autohomecar__wKjB0Vcv7tuAGG9aAAH18oGRR5A566.jpg","replycount":827,"pagecount":0,"jumppage":1,"lasttime":""},{"id":517846,"title":"这些年，C-NCAP\u201c撞\u201d过的十大安全车","mediatype":2,"type":"","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g18/M0D/76/88/160x120_0_autohomecar__wKgH6FcwZdSATP9cAADRl99aw7I165.jpg","replycount":329,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80240,"title":"公路惊险一幕！实拍小轿车雨天失控","mediatype":3,"type":"花边","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g18/M02/77/11/240x180_0_autohomecar__wKgH6FcxPVmARTy5AADyalonDr0782.jpg","replycount":32566,"pagecount":0,"jumppage":1,"lasttime":""},{"id":52273370,"title":"潮范轿跑SUV 马自达CX-4试驾直播","mediatype":5,"type":"c","time":"2016-05-10","indexdetail":"马自达CX-4论坛","smallpic":"http://club2.autoimg.cn/album/g16/M10/77/88/userphotos/2016/05/10/09/240180_wKgH5lcxPnmAR4qiAAEtMReAlOk988.jpg","replycount":780,"pagecount":0,"jumppage":3968,"lasttime":""},{"id":516783,"title":"实测：包场试车，赛道体验迈凯伦570S","mediatype":2,"type":"","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g5/M01/76/91/160x120_0_autohomecar__wKgHzFcwSzyAfB4pAAD2CdcNumU720.jpg","replycount":70,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80278,"title":"小型SUV市场中的新竞争者 16款绅宝X35","mediatype":3,"type":"到店实拍","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M04/77/57/240x180_0_autohomecar__wKgH11cxSZqAMBHKAAFVwX6hZHQ248.jpg","replycount":37830,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888347,"title":"或5月上市 奇瑞新款瑞虎3配置信息曝光","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g8/M08/7A/0F/160x120_0_autohomecar__wKgH3lcweU6AHboJAAF7JilQ_Ns892.jpg","replycount":384,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80244,"title":"赢的很轻松 看奥迪A6与傲虎的拔河对抗","mediatype":3,"type":"花边","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g4/M0C/77/5F/240x180_0_autohomecar__wKgH2lcxPpuAfin3AAEfem6MITs494.jpg","replycount":88723,"pagecount":0,"jumppage":1,"lasttime":""},{"id":517876,"title":"\u201c断轴\u201d速腾，会打个新\u201c补丁\u201d吗？","mediatype":2,"type":"","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g18/M06/76/81/160x120_0_autohomecar__wKgH6FcwYFyACxgXAAE_eq5E-48849.jpg","replycount":1185,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80236,"title":"绝对震撼 拉力赛车大雪山路强悍暴走","mediatype":3,"type":"花边","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g14/M11/78/2E/240x180_0_autohomecar__wKgH5FcxOgGAVoGAAADEnWaQN28958.jpg","replycount":39399,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888325,"title":"风阻系数为0.19 奔驰IAA概念车国内首发","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M13/5A/19/160x120_0_autohomecar__wKgFVlcxVOqAStVjAAFg6B4-gBo153.jpg","replycount":222,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888367,"title":"6月下旬亮相 野马新SUV T80预告图曝光","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M04/5A/41/160x120_0_autohomecar__wKgFXFcxUWyAU0kMAAER0hdc568359.jpg","replycount":750,"pagecount":0,"jumppage":1,"lasttime":""},{"id":514204,"title":"豪车和普通轿车的刹车有什么不同？","mediatype":2,"type":"","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g20/M03/2D/82/160x120_0_autohomecar__wKgFVFcEfL2AN4xAAAJ_wQq3tU4952.jpg","replycount":490,"pagecount":0,"jumppage":1,"lasttime":""},{"id":52062234,"title":"帅到没朋友 捷豹F-TYPE 3.0T提车","mediatype":5,"type":"c","time":"2016-05-10","indexdetail":"捷豹F-TYPE论坛","smallpic":"http://club2.autoimg.cn/album/g18/M15/6D/6A/userphotos/2016/05/03/12/240180_wKjBxVcoJLCAUIqFAAEnyk9wVic332.jpg","replycount":1874,"pagecount":0,"jumppage":2903,"lasttime":""},{"id":888366,"title":"或2018年发布 法拉利Dino假想图曝光","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g17/M0A/72/0A/160x120_0_autohomecar__wKjBxlcxTSqAVUWkAAEnKtJouUc408.jpg","replycount":194,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888364,"title":"2017年3月亮相 捷豹新款F-TYPE谍照曝光","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g21/M04/58/A5/160x120_0_autohomecar__wKjBwlcxR4qARfpwAAGraxqvlVI795.jpg","replycount":66,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888361,"title":"约300马力 下代牧马人将搭新2.0T发动机","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M11/76/8D/160x120_0_autohomecar__wKgH1VcxQA6AeqFvAAGn6utUaTQ403.jpg","replycount":443,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888359,"title":"2018年换代 新一代标致508信息曝光","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M0C/78/2F/160x120_0_autohomecar__wKgH5FcxOg2AGvENAAFBVAbjBqo249.jpg","replycount":400,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80200,"title":"太惊艳了 详拍科尔维特Z06 C7.R赛车版","mediatype":3,"type":"花边","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g9/M12/79/5F/240x180_0_autohomecar__wKgH31cwNBOANi02AAFx3hTQ2xY314.jpg","replycount":26823,"pagecount":0,"jumppage":1,"lasttime":""},{"id":517828,"title":"全国四月二手车交易分析","mediatype":2,"type":"","time":"2016-05-10","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g18/M01/76/3F/160x120_0_autohomecar__wKgH2VcwQsiAJQTwAAFsu97T8ZI057.jpg","replycount":129,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888362,"title":"曝兰博基尼Huracan Spyder LP580-2实车","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g17/M08/72/7E/160x120_0_autohomecar__wKgH2FcxPymAE3ZqAAFs_Ew4cC4923.jpg","replycount":98,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80230,"title":"最快柴油SUV 外媒试驾多面手奥迪SQ7","mediatype":3,"type":"试车","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g6/M07/76/2B/240x180_0_autohomecar__wKgHzVcwXtaAEqAeAAF0CZphb_g274.jpg","replycount":57790,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888356,"title":"年内发布 凯迪拉克新款CTS实车曝光","mediatype":1,"type":"新闻中心","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M00/77/5D/160x120_0_autohomecar__wKjBzVcxME2AGw9ZAAGnrITAEuk195.jpg","replycount":481,"pagecount":0,"jumppage":1,"lasttime":""},{"id":517419,"title":"前驱X1还是我们熟悉的宝马吗?","mediatype":2,"type":"","time":"2016-05-10","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g5/M0E/70/B3/160x120_0_autohomecar__wKjB0lcquqaAEeqBAANHz0yZERY779.jpg","replycount":606,"pagecount":0,"jumppage":1,"lasttime":"201605100900004370817"}],"topnewsinfo":{}}
     * returncode : 0
     * message :
     */

    private int returncode;
    private String message;

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class ResultBean {
        private int rowcount;
        private int pagecount;
        private int pageindex;
        /**
         * id : 888319
         * title : 11城市政策详解 2016年电动车购买宝典
         * mediatype : 1
         * type : 新闻中心
         * time : 2016-05-10
         * indexdetail :
         * smallpic : http://www2.autoimg.cn/newsdfs/g20/M0F/59/01/160x120_0_autohomecar__wKgFVFcwbU6AZyBnAAF8u6RV25c120.jpg
         * replycount : 276
         * pagecount : 0
         * jumppage : 1
         * lasttime :
         */

        private HeadlineinfoBean headlineinfo;
        private TopnewsinfoBean topnewsinfo;
        /**
         * id : 888352
         * imgurl : http://www3.autoimg.cn/newsdfs/g4/M10/76/84/640x320_0_autohomecar__wKgHy1cxG4-ADptQAAcfr3bwjcY027.jpg
         * title : 年轻就要更运动 试驾东风日产新款骐达
         * type : 试驾评测
         * replycount : 0
         * pageindex : 1
         * JumpType : 0
         * jumpurl :
         * mediatype : 1
         */

        private List<FocusimgBean> focusimg;
        /**
         * id : 80245
         * title : 驾驶室遭猛撞 看小轿车路口左转酿事故
         * mediatype : 3
         * type : 花边
         * time : 2016-05-10
         * indexdetail :
         * smallpic : http://www2.autoimg.cn/newsdfs/g11/M14/77/6A/240x180_0_autohomecar__wKgH4VcxPtSAGnXZAAFnIjuSN7E594.jpg
         * replycount : 21470
         * pagecount : 0
         * jumppage : 1
         * lasttime :
         */

        private List<NewslistBean> newslist;

        public int getRowcount() {
            return rowcount;
        }

        public void setRowcount(int rowcount) {
            this.rowcount = rowcount;
        }

        public int getPagecount() {
            return pagecount;
        }

        public void setPagecount(int pagecount) {
            this.pagecount = pagecount;
        }

        public int getPageindex() {
            return pageindex;
        }

        public void setPageindex(int pageindex) {
            this.pageindex = pageindex;
        }

        public HeadlineinfoBean getHeadlineinfo() {
            return headlineinfo;
        }

        public void setHeadlineinfo(HeadlineinfoBean headlineinfo) {
            this.headlineinfo = headlineinfo;
        }

        public TopnewsinfoBean getTopnewsinfo() {
            return topnewsinfo;
        }

        public void setTopnewsinfo(TopnewsinfoBean topnewsinfo) {
            this.topnewsinfo = topnewsinfo;
        }

        public List<FocusimgBean> getFocusimg() {
            return focusimg;
        }

        public void setFocusimg(List<FocusimgBean> focusimg) {
            this.focusimg = focusimg;
        }

        public List<NewslistBean> getNewslist() {
            return newslist;
        }

        public void setNewslist(List<NewslistBean> newslist) {
            this.newslist = newslist;
        }

        public static class HeadlineinfoBean {
            private int id;
            private String title;
            private int mediatype;
            private String type;
            private String time;
            private String indexdetail;
            private String smallpic;
            private int replycount;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public int getMediatype() {
                return mediatype;
            }

            public void setMediatype(int mediatype) {
                this.mediatype = mediatype;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getIndexdetail() {
                return indexdetail;
            }

            public void setIndexdetail(String indexdetail) {
                this.indexdetail = indexdetail;
            }

            public String getSmallpic() {
                return smallpic;
            }

            public void setSmallpic(String smallpic) {
                this.smallpic = smallpic;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }
        }

        public static class TopnewsinfoBean {
        }

        public static class FocusimgBean {
            private int id;
            private String imgurl;
            private String title;
            private String type;
            private int replycount;
            private int pageindex;
            private int JumpType;
            private String jumpurl;
            private int mediatype;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getImgurl() {
                return imgurl;
            }

            public void setImgurl(String imgurl) {
                this.imgurl = imgurl;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }

            public int getPageindex() {
                return pageindex;
            }

            public void setPageindex(int pageindex) {
                this.pageindex = pageindex;
            }

            public int getJumpType() {
                return JumpType;
            }

            public void setJumpType(int JumpType) {
                this.JumpType = JumpType;
            }

            public String getJumpurl() {
                return jumpurl;
            }

            public void setJumpurl(String jumpurl) {
                this.jumpurl = jumpurl;
            }

            public int getMediatype() {
                return mediatype;
            }

            public void setMediatype(int mediatype) {
                this.mediatype = mediatype;
            }
        }

        public static class NewslistBean {
            private int id;
            private String title;
            private int mediatype;
            private String type;
            private String time;
            private String indexdetail;
            private String smallpic;
            private int replycount;
            private int pagecount;
            private int jumppage;
            private String lasttime;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public int getMediatype() {
                return mediatype;
            }

            public void setMediatype(int mediatype) {
                this.mediatype = mediatype;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getIndexdetail() {
                return indexdetail;
            }

            public void setIndexdetail(String indexdetail) {
                this.indexdetail = indexdetail;
            }

            public String getSmallpic() {
                return smallpic;
            }

            public void setSmallpic(String smallpic) {
                this.smallpic = smallpic;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }

            public int getPagecount() {
                return pagecount;
            }

            public void setPagecount(int pagecount) {
                this.pagecount = pagecount;
            }

            public int getJumppage() {
                return jumppage;
            }

            public void setJumppage(int jumppage) {
                this.jumppage = jumppage;
            }

            public String getLasttime() {
                return lasttime;
            }

            public void setLasttime(String lasttime) {
                this.lasttime = lasttime;
            }
        }
    }
}
